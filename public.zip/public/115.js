(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[115],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/Gestao-abastecimentos/bombas/bomba_form.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/Gestao-abastecimentos/bombas/bomba_form.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, exports) {

throw new Error("Module build failed (from ./node_modules/babel-loader/lib/index.js):\nSyntaxError: C:\\wamp64\\www\\portal_pfuxela\\resources\\js\\src\\views\\Gestao-abastecimentos\\bombas\\bomba_form.vue: Unexpected token (333:11)\n\n\u001b[0m \u001b[90m 331 |\u001b[39m     \u001b[36mfunction\u001b[39m \u001b[33mAbastecerBomba\u001b[39m() {\u001b[0m\n\u001b[0m \u001b[90m 332 |\u001b[39m\u001b[0m\n\u001b[0m\u001b[31m\u001b[1m>\u001b[22m\u001b[39m\u001b[90m 333 |\u001b[39m       \u001b[36mthis\u001b[39m\u001b[33m.\u001b[39m\u001b[33m.\u001b[39mput(\u001b[32m`/api/abastecimentoBomba/${form.value.id}`\u001b[39m)\u001b[0m\n\u001b[0m \u001b[90m     |\u001b[39m            \u001b[31m\u001b[1m^\u001b[22m\u001b[39m\u001b[0m\n\u001b[0m \u001b[90m 334 |\u001b[39m         \u001b[33m.\u001b[39mthen(response \u001b[33m=>\u001b[39m {\u001b[0m\n\u001b[0m \u001b[90m 335 |\u001b[39m           toast({\u001b[0m\n\u001b[0m \u001b[90m 336 |\u001b[39m             component\u001b[33m:\u001b[39m \u001b[33mToastificationContent\u001b[39m\u001b[33m,\u001b[39m\u001b[0m\n    at instantiate (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:72:32)\n    at constructor (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:358:12)\n    at Object.raise (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:3334:19)\n    at Object.unexpected (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:3372:16)\n    at Object.parseIdentifierName (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:13970:18)\n    at Object.parseIdentifier (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:13950:23)\n    at Object.parseMember (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:12618:28)\n    at Object.parseSubscript (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:12592:21)\n    at Object.parseSubscripts (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:12556:19)\n    at Object.parseExprSubscripts (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:12545:17)\n    at Object.parseUpdate (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:12518:21)\n    at Object.parseMaybeUnary (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:12489:23)\n    at Object.parseMaybeUnaryOrPrivate (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:12283:61)\n    at Object.parseExprOps (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:12290:23)\n    at Object.parseMaybeConditional (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:12260:23)\n    at Object.parseMaybeAssign (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:12213:21)\n    at Object.parseExpressionBase (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:12149:23)\n    at C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:12143:39\n    at Object.allowInAnd (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:14231:16)\n    at Object.parseExpression (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:12143:17)\n    at Object.parseStatementContent (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:14671:23)\n    at Object.parseStatement (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:14528:17)\n    at Object.parseBlockOrModuleBlockBody (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:15167:25)\n    at Object.parseBlockBody (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:15158:10)\n    at Object.parseBlock (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:15142:10)\n    at Object.parseFunctionBody (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:13836:24)\n    at Object.parseFunctionBodyAndFinish (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:13820:10)\n    at C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:15317:12\n    at Object.withSmartMixTopicForbiddingContext (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:14208:14)\n    at Object.parseFunction (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:15316:10)\n    at Object.parseFunctionStatement (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:14916:17)\n    at Object.parseStatementContent (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:14572:21)\n    at Object.parseStatement (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:14528:17)\n    at Object.parseBlockOrModuleBlockBody (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:15167:25)\n    at Object.parseBlockBody (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:15158:10)\n    at Object.parseBlock (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:15142:10)");

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/Gestao-abastecimentos/bombas/bomba_form.vue?vue&type=template&id=351ff1bc&":
/*!*****************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/Gestao-abastecimentos/bombas/bomba_form.vue?vue&type=template&id=351ff1bc& ***!
  \*****************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "section" },
    [
      _c(
        "b-card",
        { attrs: { "no-body": "" } },
        [
          _c("div", { staticClass: "card-header" }, [
            _c("h3", { staticClass: "card-title" }, [
              _vm._v("Abastecimento da bomba interna"),
            ]),
          ]),
          _vm._v(" "),
          _c(
            "b-card-body",
            [
              _c("div", { staticClass: "card-header" }, [
                _c("h3", { staticClass: "card-title" }, [
                  _vm._v("Abastecimento recem pedidos em espera"),
                ]),
              ]),
              _vm._v(" "),
              _c("table", { staticClass: "table table-stripped" }, [
                _c("thead", [
                  _c("tr", [
                    _c("th", [_vm._v("Ordem")]),
                    _vm._v(" "),
                    _c("th", [_vm._v("Fornecedor")]),
                    _vm._v(" "),
                    _c("th", [_vm._v("Email do fornecedor")]),
                    _vm._v(" "),
                    _c("th", [_vm._v("Preço/ltr")]),
                    _vm._v(" "),
                    _c("th", [_vm._v("Qtd")]),
                    _vm._v(" "),
                    _c("th", [_vm._v("Total")]),
                    _vm._v(" "),
                    _c("th", [_vm._v("Submetido por")]),
                    _vm._v(" "),
                    _c("th"),
                  ]),
                ]),
                _vm._v(" "),
                _c(
                  "tbody",
                  _vm._l(_vm.abastecimento_pendente, function (abs, i) {
                    return _c("tr", { key: i }, [
                      _c("td", [_vm._v(_vm._s(abs.ordem.codigo_ordem))]),
                      _vm._v(" "),
                      _c("td", [_vm._v(_vm._s(abs.fornecedor))]),
                      _vm._v(" "),
                      _c("td", [_vm._v(_vm._s(abs.fornecedor_contacto))]),
                      _vm._v(" "),
                      _c("td", [_vm._v(_vm._s(abs.preco_combustivel))]),
                      _vm._v(" "),
                      _c("td", [_vm._v(_vm._s(abs.qtd_abastecida))]),
                      _vm._v(" "),
                      _c("td", [
                        _vm._v(
                          _vm._s(abs.preco_combustivel * abs.qtd_abastecida)
                        ),
                      ]),
                      _vm._v(" "),
                      _c("td", [_vm._v(_vm._s(abs.user.name))]),
                      _vm._v(" "),
                      _c(
                        "td",
                        [
                          _c(
                            "b-button",
                            {
                              attrs: { sm: "" },
                              on: {
                                click: function ($event) {
                                  return _vm.openModal(abs)
                                },
                              },
                            },
                            [
                              _c("i", { staticClass: "fas fa-gas-pump" }),
                              _vm._v(" receber"),
                            ]
                          ),
                        ],
                        1
                      ),
                    ])
                  }),
                  0
                ),
              ]),
              _vm._v(" "),
              _c("hr"),
              _vm._v(" "),
              _c(
                "b-row",
                [
                  _c(
                    "b-col",
                    { attrs: { cols: "12", xl: "12", md: "12" } },
                    [
                      _c(
                        "b-card",
                        { attrs: { "no-body": "" } },
                        [
                          _c(
                            "b-form",
                            {
                              on: {
                                submit: function ($event) {
                                  $event.preventDefault()
                                  return _vm.RequisitarAbastecimento.apply(
                                    null,
                                    arguments
                                  )
                                },
                              },
                            },
                            [
                              _c(
                                "b-row",
                                [
                                  _c(
                                    "b-col",
                                    {
                                      attrs: { cols: "12", md: "12", lg: "8" },
                                    },
                                    [
                                      _c(
                                        "b-form-group",
                                        { attrs: { label: "Combustivel" } },
                                        [
                                          _c("v-select", {
                                            attrs: {
                                              options: ["Diesel", "Gasolina"],
                                            },
                                            model: {
                                              value:
                                                _vm.form.tipo_de_combustivel,
                                              callback: function ($$v) {
                                                _vm.$set(
                                                  _vm.form,
                                                  "tipo_de_combustivel",
                                                  $$v
                                                )
                                              },
                                              expression:
                                                "form.tipo_de_combustivel",
                                            },
                                          }),
                                        ],
                                        1
                                      ),
                                    ],
                                    1
                                  ),
                                  _vm._v(" "),
                                  _c(
                                    "b-col",
                                    { attrs: { cols: "12", md: "6", lg: "6" } },
                                    [
                                      _c(
                                        "b-form-group",
                                        { attrs: { label: "Fornecedor" } },
                                        [
                                          _c("v-select", {
                                            attrs: {
                                              label: "nome_bombas",
                                              options: _vm.bombas,
                                              reduce: function (bombas) {
                                                return bombas.id
                                              },
                                            },
                                            model: {
                                              value: _vm.form.fornecedor_id,
                                              callback: function ($$v) {
                                                _vm.$set(
                                                  _vm.form,
                                                  "fornecedor_id",
                                                  $$v
                                                )
                                              },
                                              expression: "form.fornecedor_id",
                                            },
                                          }),
                                        ],
                                        1
                                      ),
                                    ],
                                    1
                                  ),
                                  _vm._v(" "),
                                  _c(
                                    "b-col",
                                    { attrs: { cols: "12", md: "6", lg: "6" } },
                                    [
                                      _c(
                                        "b-form-group",
                                        { attrs: { label: "Qtd a abastecer" } },
                                        [
                                          _c("b-form-input", {
                                            attrs: { type: "number" },
                                            model: {
                                              value: _vm.form.qtd_abastecida,
                                              callback: function ($$v) {
                                                _vm.$set(
                                                  _vm.form,
                                                  "qtd_abastecida",
                                                  $$v
                                                )
                                              },
                                              expression: "form.qtd_abastecida",
                                            },
                                          }),
                                        ],
                                        1
                                      ),
                                    ],
                                    1
                                  ),
                                  _vm._v(" "),
                                  _c(
                                    "b-col",
                                    { attrs: { cols: "12", md: "6", lg: "6" } },
                                    [
                                      _c(
                                        "b-form-group",
                                        {
                                          attrs: {
                                            label: "Preço de aquisiçao",
                                          },
                                        },
                                        [
                                          _c("b-form-input", {
                                            attrs: { type: "text" },
                                            model: {
                                              value: _vm.form.preco_combustivel,
                                              callback: function ($$v) {
                                                _vm.$set(
                                                  _vm.form,
                                                  "preco_combustivel",
                                                  $$v
                                                )
                                              },
                                              expression:
                                                "form.preco_combustivel",
                                            },
                                          }),
                                        ],
                                        1
                                      ),
                                    ],
                                    1
                                  ),
                                  _vm._v(" "),
                                  _c(
                                    "b-col",
                                    { attrs: { cols: "12", md: "6", lg: "6" } },
                                    [
                                      _c(
                                        "b-form-group",
                                        { attrs: { label: "Data" } },
                                        [
                                          _c("b-form-datepicker", {
                                            attrs: {
                                              "calendar-width": "100%",
                                              locale: "pt-Br",
                                            },
                                            model: {
                                              value: _vm.form.data_recepcao,
                                              callback: function ($$v) {
                                                _vm.$set(
                                                  _vm.form,
                                                  "data_recepcao",
                                                  $$v
                                                )
                                              },
                                              expression: "form.data_recepcao",
                                            },
                                          }),
                                        ],
                                        1
                                      ),
                                    ],
                                    1
                                  ),
                                  _vm._v(" "),
                                  _c(
                                    "b-col",
                                    { attrs: { cols: "12", md: "6", lg: "6" } },
                                    [
                                      _c(
                                        "b-form-group",
                                        { attrs: { label: "Inclui Iva" } },
                                        [
                                          _c(
                                            "b-form-checkbox",
                                            {
                                              attrs: { checked: false },
                                              model: {
                                                value: _vm.form.iva,
                                                callback: function ($$v) {
                                                  _vm.$set(_vm.form, "iva", $$v)
                                                },
                                                expression: "form.iva",
                                              },
                                            },
                                            [_vm._v("Inc(IVA)")]
                                          ),
                                        ],
                                        1
                                      ),
                                    ],
                                    1
                                  ),
                                ],
                                1
                              ),
                              _vm._v(" "),
                              _c(
                                "b-row",
                                [
                                  _c(
                                    "b-col",
                                    {
                                      attrs: { cols: "12", md: "12", lg: "12" },
                                    },
                                    [
                                      _c(
                                        "b-button",
                                        {
                                          attrs: {
                                            variant: "success",
                                            type: "submit",
                                          },
                                        },
                                        [_vm._v("enviar ordem")]
                                      ),
                                      _vm._v(" "),
                                      _c(
                                        "b-button",
                                        { attrs: { variant: "secondary" } },
                                        [_vm._v("cancelar")]
                                      ),
                                    ],
                                    1
                                  ),
                                ],
                                1
                              ),
                            ],
                            1
                          ),
                        ],
                        1
                      ),
                    ],
                    1
                  ),
                ],
                1
              ),
            ],
            1
          ),
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "b-modal",
        {
          ref: "modal-form",
          attrs: {
            id: "modal-prevent-closing",
            "hide-footer": "",
            title: "Submeter Recepcao de combustivel",
            size: "lg",
          },
        },
        [
          _c("validation-observer", {
            ref: "refFormObserver",
            scopedSlots: _vm._u([
              {
                key: "default",
                fn: function (ref) {
                  var handleSubmit = ref.handleSubmit
                  return [
                    _c(
                      "b-form",
                      {
                        on: {
                          submit: function ($event) {
                            $event.preventDefault()
                            return handleSubmit(_vm.AbastecerBomba)
                          },
                          reset: _vm.onReset,
                        },
                      },
                      [
                        _c(
                          "b-row",
                          [
                            _c(
                              "b-col",
                              { attrs: { cols: "12", lg: "6", md: "6" } },
                              [
                                _c("input", {
                                  directives: [
                                    {
                                      name: "model",
                                      rawName: "v-model",
                                      value: _vm.form.id,
                                      expression: "form.id",
                                    },
                                  ],
                                  attrs: { type: "hidden" },
                                  domProps: { value: _vm.form.id },
                                  on: {
                                    input: function ($event) {
                                      if ($event.target.composing) {
                                        return
                                      }
                                      _vm.$set(
                                        _vm.form,
                                        "id",
                                        $event.target.value
                                      )
                                    },
                                  },
                                }),
                                _vm._v(" "),
                                _c("validation-provider", {
                                  attrs: {
                                    name: "nome_motorista",
                                    rules: "required",
                                  },
                                  scopedSlots: _vm._u(
                                    [
                                      {
                                        key: "default",
                                        fn: function (validationContext) {
                                          return [
                                            _c(
                                              "b-form-group",
                                              {
                                                attrs: {
                                                  "invalid-feedback":
                                                    "Nome do motorista obrigatorio",
                                                  label: "Motorista",
                                                },
                                              },
                                              [
                                                _c("b-form-input", {
                                                  attrs: {
                                                    type: "text",
                                                    state:
                                                      _vm.getValidationState(
                                                        validationContext
                                                      ),
                                                    trim: "",
                                                    required: "",
                                                  },
                                                  model: {
                                                    value:
                                                      _vm.form.nome_motorista,
                                                    callback: function ($$v) {
                                                      _vm.$set(
                                                        _vm.form,
                                                        "nome_motorista",
                                                        $$v
                                                      )
                                                    },
                                                    expression:
                                                      "form.nome_motorista",
                                                  },
                                                }),
                                                _vm._v(" "),
                                                _c("b-form-invalid-feedback", [
                                                  _vm._v(
                                                    "\n                " +
                                                      _vm._s(
                                                        validationContext
                                                          .errors[0]
                                                      ) +
                                                      "\n              "
                                                  ),
                                                ]),
                                              ],
                                              1
                                            ),
                                          ]
                                        },
                                      },
                                    ],
                                    null,
                                    true
                                  ),
                                }),
                              ],
                              1
                            ),
                            _vm._v(" "),
                            _c(
                              "b-col",
                              { attrs: { cols: "12", lg: "6", md: "6" } },
                              [
                                _c("validation-provider", {
                                  attrs: {
                                    name: "Identificacao",
                                    rules: "required",
                                  },
                                  scopedSlots: _vm._u(
                                    [
                                      {
                                        key: "default",
                                        fn: function (validationContext) {
                                          return [
                                            _c(
                                              "b-form-group",
                                              {
                                                attrs: {
                                                  "invalid-feedback":
                                                    "Identificacao do motorista obrigatorio",
                                                  label:
                                                    "Identificacao e tipo de documento",
                                                },
                                              },
                                              [
                                                _c("b-form-input", {
                                                  attrs: {
                                                    type: "text",
                                                    state:
                                                      _vm.getValidationState(
                                                        validationContext
                                                      ),
                                                    trim: "",
                                                    required: "",
                                                  },
                                                  model: {
                                                    value:
                                                      _vm.form.identificacao,
                                                    callback: function ($$v) {
                                                      _vm.$set(
                                                        _vm.form,
                                                        "identificacao",
                                                        $$v
                                                      )
                                                    },
                                                    expression:
                                                      "form.identificacao",
                                                  },
                                                }),
                                                _vm._v(" "),
                                                _c("b-form-invalid-feedback", [
                                                  _vm._v(
                                                    "\n                " +
                                                      _vm._s(
                                                        validationContext
                                                          .errors[0]
                                                      ) +
                                                      "\n              "
                                                  ),
                                                ]),
                                              ],
                                              1
                                            ),
                                          ]
                                        },
                                      },
                                    ],
                                    null,
                                    true
                                  ),
                                }),
                              ],
                              1
                            ),
                            _vm._v(" "),
                            _c(
                              "b-col",
                              { attrs: { cols: "12", lg: "6", md: "6" } },
                              [
                                _c("validation-provider", {
                                  attrs: {
                                    name: "Selo de abastecimento",
                                    rules: "required",
                                  },
                                  scopedSlots: _vm._u(
                                    [
                                      {
                                        key: "default",
                                        fn: function (validationContext) {
                                          return [
                                            _c(
                                              "b-form-group",
                                              {
                                                attrs: {
                                                  "invalid-feedback":
                                                    "Selo de abastecimento obrigatorio",
                                                  label:
                                                    "Selo de abastecimento",
                                                },
                                              },
                                              [
                                                _c("b-form-input", {
                                                  attrs: {
                                                    type: "text",
                                                    state:
                                                      _vm.getValidationState(
                                                        validationContext
                                                      ),
                                                    trim: "",
                                                    required: "",
                                                  },
                                                  model: {
                                                    value:
                                                      _vm.form
                                                        .selo_abastecimento,
                                                    callback: function ($$v) {
                                                      _vm.$set(
                                                        _vm.form,
                                                        "selo_abastecimento",
                                                        $$v
                                                      )
                                                    },
                                                    expression:
                                                      "form.selo_abastecimento",
                                                  },
                                                }),
                                                _vm._v(" "),
                                                _c("b-form-invalid-feedback", [
                                                  _vm._v(
                                                    "\n                " +
                                                      _vm._s(
                                                        validationContext
                                                          .errors[0]
                                                      ) +
                                                      "\n              "
                                                  ),
                                                ]),
                                              ],
                                              1
                                            ),
                                          ]
                                        },
                                      },
                                    ],
                                    null,
                                    true
                                  ),
                                }),
                              ],
                              1
                            ),
                            _vm._v(" "),
                            _c(
                              "b-col",
                              { attrs: { cols: "12", lg: "6", md: "6" } },
                              [
                                _c("validation-provider", {
                                  attrs: {
                                    name: "Viatura do fornecedor",
                                    rules: "required",
                                  },
                                  scopedSlots: _vm._u(
                                    [
                                      {
                                        key: "default",
                                        fn: function (validationContext) {
                                          return [
                                            _c(
                                              "b-form-group",
                                              {
                                                attrs: {
                                                  "invalid-feedback":
                                                    "Identifique a viatura",
                                                  label:
                                                    "Viatura do fornecedor",
                                                },
                                              },
                                              [
                                                _c("b-form-input", {
                                                  attrs: {
                                                    type: "text",
                                                    state:
                                                      _vm.getValidationState(
                                                        validationContext
                                                      ),
                                                    trim: "",
                                                    required: "",
                                                  },
                                                  model: {
                                                    value:
                                                      _vm.form
                                                        .viatura_fornecedor,
                                                    callback: function ($$v) {
                                                      _vm.$set(
                                                        _vm.form,
                                                        "viatura_fornecedor",
                                                        $$v
                                                      )
                                                    },
                                                    expression:
                                                      "form.viatura_fornecedor",
                                                  },
                                                }),
                                                _vm._v(" "),
                                                _c("b-form-invalid-feedback", [
                                                  _vm._v(
                                                    "\n                " +
                                                      _vm._s(
                                                        validationContext
                                                          .errors[0]
                                                      ) +
                                                      "\n              "
                                                  ),
                                                ]),
                                              ],
                                              1
                                            ),
                                          ]
                                        },
                                      },
                                    ],
                                    null,
                                    true
                                  ),
                                }),
                              ],
                              1
                            ),
                            _vm._v(" "),
                            _c(
                              "b-col",
                              { attrs: { cols: "12", lg: "12", md: "12" } },
                              [
                                _c(
                                  "b-form-group",
                                  { attrs: { label: "Observacao" } },
                                  [
                                    _c("b-form-textarea", {
                                      model: {
                                        value: _vm.form.observacao,
                                        callback: function ($$v) {
                                          _vm.$set(_vm.form, "observacao", $$v)
                                        },
                                        expression: "form.observacao",
                                      },
                                    }),
                                  ],
                                  1
                                ),
                              ],
                              1
                            ),
                          ],
                          1
                        ),
                        _vm._v(" "),
                        _c(
                          "b-button",
                          {
                            staticClass: "mt-2",
                            attrs: {
                              variant: "outline-success",
                              type: "submit",
                            },
                          },
                          [_vm._v("Submeter")]
                        ),
                      ],
                      1
                    ),
                  ]
                },
              },
            ]),
          }),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./resources/js/src/views/Gestao-abastecimentos/bombas/bomba_form.vue":
/*!****************************************************************************!*\
  !*** ./resources/js/src/views/Gestao-abastecimentos/bombas/bomba_form.vue ***!
  \****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _bomba_form_vue_vue_type_template_id_351ff1bc___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./bomba_form.vue?vue&type=template&id=351ff1bc& */ "./resources/js/src/views/Gestao-abastecimentos/bombas/bomba_form.vue?vue&type=template&id=351ff1bc&");
/* harmony import */ var _bomba_form_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./bomba_form.vue?vue&type=script&lang=js& */ "./resources/js/src/views/Gestao-abastecimentos/bombas/bomba_form.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _bomba_form_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _bomba_form_vue_vue_type_template_id_351ff1bc___WEBPACK_IMPORTED_MODULE_0__["render"],
  _bomba_form_vue_vue_type_template_id_351ff1bc___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/Gestao-abastecimentos/bombas/bomba_form.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/Gestao-abastecimentos/bombas/bomba_form.vue?vue&type=script&lang=js&":
/*!*****************************************************************************************************!*\
  !*** ./resources/js/src/views/Gestao-abastecimentos/bombas/bomba_form.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_bomba_form_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./bomba_form.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/Gestao-abastecimentos/bombas/bomba_form.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_bomba_form_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/Gestao-abastecimentos/bombas/bomba_form.vue?vue&type=template&id=351ff1bc&":
/*!***********************************************************************************************************!*\
  !*** ./resources/js/src/views/Gestao-abastecimentos/bombas/bomba_form.vue?vue&type=template&id=351ff1bc& ***!
  \***********************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_bomba_form_vue_vue_type_template_id_351ff1bc___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./bomba_form.vue?vue&type=template&id=351ff1bc& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/Gestao-abastecimentos/bombas/bomba_form.vue?vue&type=template&id=351ff1bc&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_bomba_form_vue_vue_type_template_id_351ff1bc___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_bomba_form_vue_vue_type_template_id_351ff1bc___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);