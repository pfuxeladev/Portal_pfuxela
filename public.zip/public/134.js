(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[134],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/Gestao-abastecimentos/abastecimentos/relatorio_geral.vue?vue&type=script&lang=js&":
/*!**************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/Gestao-abastecimentos/abastecimentos/relatorio_geral.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, exports) {

throw new Error("Module build failed (from ./node_modules/babel-loader/lib/index.js):\nSyntaxError: C:\\wamp64\\www\\portal_pfuxela\\resources\\js\\src\\views\\Gestao-abastecimentos\\abastecimentos\\relatorio_geral.vue: Unexpected token, expected \",\" (376:127)\n\n\u001b[0m \u001b[90m 374 |\u001b[39m       } \u001b[36melse\u001b[39m \u001b[36mif\u001b[39m (\u001b[36mthis\u001b[39m\u001b[33m.\u001b[39mdateReport \u001b[33m!==\u001b[39m \u001b[32m''\u001b[39m \u001b[33m&&\u001b[39m \u001b[36mthis\u001b[39m\u001b[33m.\u001b[39mintervalo \u001b[33m!==\u001b[39m \u001b[32m''\u001b[39m \u001b[33m&&\u001b[39m \u001b[36mthis\u001b[39m\u001b[33m.\u001b[39msearchDatas \u001b[33m!==\u001b[39m \u001b[32m''\u001b[39m) {\u001b[0m\n\u001b[0m \u001b[90m 375 |\u001b[39m         \u001b[36mthis\u001b[39m\u001b[33m.\u001b[39m$http\u001b[0m\n\u001b[0m\u001b[31m\u001b[1m>\u001b[22m\u001b[39m\u001b[90m 376 |\u001b[39m           \u001b[33m.\u001b[39mpost(\u001b[32m'/api/printRelatorio'\u001b[39m\u001b[33m,\u001b[39m {dateReport\u001b[33m:\u001b[39m \u001b[36mthis\u001b[39m\u001b[33m.\u001b[39mdateReport\u001b[33m,\u001b[39m intervalo\u001b[33m:\u001b[39m \u001b[36mthis\u001b[39m\u001b[33m.\u001b[39mintervalo\u001b[33m,\u001b[39m searchDatas\u001b[33m:\u001b[39m \u001b[36mthis\u001b[39m\u001b[33m.\u001b[39msearchDatas} {\u001b[0m\n\u001b[0m \u001b[90m     |\u001b[39m                                                                                                                                \u001b[31m\u001b[1m^\u001b[22m\u001b[39m\u001b[0m\n\u001b[0m \u001b[90m 377 |\u001b[39m             responseType\u001b[33m:\u001b[39m \u001b[32m'blob'\u001b[39m\u001b[33m,\u001b[39m\u001b[0m\n\u001b[0m \u001b[90m 378 |\u001b[39m             \u001b[33mAccept\u001b[39m\u001b[33m:\u001b[39m \u001b[32m'application/pdf'\u001b[39m\u001b[33m,\u001b[39m\u001b[0m\n\u001b[0m \u001b[90m 379 |\u001b[39m           })\u001b[0m\n    at instantiate (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:72:32)\n    at constructor (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:358:12)\n    at Object.raise (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:3334:19)\n    at Object.unexpected (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:3372:16)\n    at Object.expect (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:4001:28)\n    at Object.parseCallExpressionArguments (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:12747:14)\n    at Object.parseCoverCallAndAsyncArrowHead (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:12662:29)\n    at Object.parseSubscript (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:12587:19)\n    at Object.parseSubscripts (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:12556:19)\n    at Object.parseExprSubscripts (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:12545:17)\n    at Object.parseUpdate (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:12518:21)\n    at Object.parseMaybeUnary (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:12489:23)\n    at Object.parseMaybeUnaryOrPrivate (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:12283:61)\n    at Object.parseExprOps (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:12290:23)\n    at Object.parseMaybeConditional (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:12260:23)\n    at Object.parseMaybeAssign (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:12213:21)\n    at Object.parseExpressionBase (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:12149:23)\n    at C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:12143:39\n    at Object.allowInAnd (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:14231:16)\n    at Object.parseExpression (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:12143:17)\n    at Object.parseStatementContent (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:14671:23)\n    at Object.parseStatement (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:14528:17)\n    at Object.parseBlockOrModuleBlockBody (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:15167:25)\n    at Object.parseBlockBody (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:15158:10)\n    at Object.parseBlock (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:15142:10)\n    at Object.parseStatementContent (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:14612:21)\n    at Object.parseStatement (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:14528:17)\n    at Object.parseIfStatement (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:14922:28)\n    at Object.parseStatementContent (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:14579:21)\n    at Object.parseStatement (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:14528:17)\n    at Object.parseIfStatement (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:14923:42)\n    at Object.parseStatementContent (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:14579:21)\n    at Object.parseStatement (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:14528:17)\n    at Object.parseIfStatement (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:14923:42)\n    at Object.parseStatementContent (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:14579:21)\n    at Object.parseStatement (C:\\wamp64\\www\\portal_pfuxela\\node_modules\\@babel\\parser\\lib\\index.js:14528:17)");

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/Gestao-abastecimentos/abastecimentos/relatorio_geral.vue?vue&type=template&id=457c7aff&":
/*!******************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/Gestao-abastecimentos/abastecimentos/relatorio_geral.vue?vue&type=template&id=457c7aff& ***!
  \******************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { attrs: { id: "relatorio-geral" } }, [
    _c(
      "section",
      [
        _c(
          "b-card",
          { attrs: { "no-body": "" } },
          [
            _c(
              "b-card-header",
              { staticClass: "pb-50" },
              [
                _c("b-card-title", [
                  _vm._v("Relatório Geral dos abastecimento"),
                ]),
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "div",
              { staticClass: "m-2" },
              [
                _c(
                  "b-row",
                  [
                    _c(
                      "b-col",
                      { attrs: { cols: "4", md: "4" } },
                      [
                        _c(
                          "b-form-group",
                          {
                            attrs: {
                              id: "input-group-8",
                              label: "Dados da lista abaixo:",
                              "label-for": "input-8",
                            },
                          },
                          [
                            _c("b-form-input", {
                              staticClass: "d-inline-block mr-1",
                              attrs: { placeholder: "pesquisar..." },
                              model: {
                                value: _vm.searchDatas,
                                callback: function ($$v) {
                                  _vm.searchDatas = $$v
                                },
                                expression: "searchDatas",
                              },
                            }),
                          ],
                          1
                        ),
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "b-col",
                      { attrs: { cols: "4", md: "4" } },
                      [
                        _c(
                          "b-form-group",
                          {
                            attrs: {
                              id: "input-group-8",
                              label: "Data cadastro de viatura:",
                              "label-for": "input-8",
                              description: "Data cadastro de viatura.",
                            },
                          },
                          [
                            _c("date-picker", {
                              staticClass: "mb-1",
                              staticStyle: { width: "100%" },
                              attrs: {
                                "value-type": "format",
                                format: "YYYY-MM-DD",
                                id: "example-datepicker1",
                                range: "",
                                locale: "pt",
                              },
                              model: {
                                value: _vm.intervalo,
                                callback: function ($$v) {
                                  _vm.intervalo = $$v
                                },
                                expression: "intervalo",
                              },
                            }),
                          ],
                          1
                        ),
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "b-col",
                      { attrs: { cols: "4", md: "4" } },
                      [
                        _c(
                          "b-form-group",
                          {
                            attrs: {
                              label: "Filtrar por periodo:",
                              "label-for": "input-8",
                              description: "Datas periodicas.",
                            },
                          },
                          [
                            _c("v-select", {
                              attrs: {
                                dir: _vm.$store.state.appConfig.isRTL
                                  ? "rtl"
                                  : "ltr",
                                options: _vm.dateOptions,
                                reduce: function (dateOptions) {
                                  return dateOptions.value
                                },
                                clearable: false,
                              },
                              model: {
                                value: _vm.dateReport,
                                callback: function ($$v) {
                                  _vm.dateReport = $$v
                                },
                                expression: "dateReport",
                              },
                            }),
                          ],
                          1
                        ),
                      ],
                      1
                    ),
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "b-row",
                  [
                    _c(
                      "b-col",
                      {
                        staticClass:
                          "\n              d-flex\n              align-items-center\n              justify-content-start\n              mb-1 mb-md-0\n            ",
                        attrs: { cols: "12", md: "4" },
                      },
                      [
                        _c("label", [_vm._v("mostrar")]),
                        _vm._v(" "),
                        _c("v-select", {
                          staticClass: "per-page-selector d-inline-block mx-50",
                          attrs: {
                            dir: _vm.$store.state.appConfig.isRTL
                              ? "rtl"
                              : "ltr",
                            options: _vm.perPageOptions,
                            clearable: false,
                          },
                          model: {
                            value: _vm.perPage,
                            callback: function ($$v) {
                              _vm.perPage = $$v
                            },
                            expression: "perPage",
                          },
                        }),
                        _vm._v(" "),
                        _c("label", [_vm._v("entradas")]),
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c("b-col"),
                    _vm._v(" "),
                    _c("b-col"),
                    _vm._v(" "),
                    _c("b-col"),
                  ],
                  1
                ),
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "b-card-body",
              [
                _c(
                  "b-row",
                  [
                    _c(
                      "b-col",
                      { attrs: { cols: "3" } },
                      [
                        _c(
                          "b-button",
                          {
                            attrs: { variant: "outline-primary" },
                            on: {
                              click: function ($event) {
                                return _vm.imprimir()
                              },
                            },
                          },
                          [
                            _c("i", { staticClass: "fas fa-print" }),
                            _vm._v(" Imprimir"),
                          ]
                        ),
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c(
                      "b-col",
                      {
                        staticClass: "table-responsive",
                        attrs: { cols: "12", xl: "12", md: "12" },
                      },
                      [
                        _c("b-table", {
                          ref: "RelatorioGeral",
                          attrs: {
                            items: _vm.generalReport,
                            fields: _vm.fieldColumns,
                            "primary-key": "id",
                            "sort-by": _vm.sortBy,
                            "show-empty": "",
                            "empty-text": "Nenhum dado encontrado",
                            "sort-desc": _vm.isSortDirDesc,
                            "head-variant": "light",
                          },
                          on: {
                            "update:sortBy": function ($event) {
                              _vm.sortBy = $event
                            },
                            "update:sort-by": function ($event) {
                              _vm.sortBy = $event
                            },
                            "update:sortDesc": function ($event) {
                              _vm.isSortDirDesc = $event
                            },
                            "update:sort-desc": function ($event) {
                              _vm.isSortDirDesc = $event
                            },
                          },
                          scopedSlots: _vm._u([
                            {
                              key: "cell(ordem)",
                              fn: function (data) {
                                return [
                                  data.item.ordem !== null
                                    ? _c("span", [
                                        _vm._v(
                                          "\n                  " +
                                            _vm._s(
                                              data.item.ordem.codigo_ordem
                                            ) +
                                            "\n                "
                                        ),
                                      ])
                                    : _vm._e(),
                                ]
                              },
                            },
                            {
                              key: "cell(Data_de_emissao)",
                              fn: function (data) {
                                return [
                                  _vm._v(
                                    "\n                " +
                                      _vm._s(
                                        _vm.dateTime(data.item.ordem.updated_at)
                                      ) +
                                      "\n              "
                                  ),
                                ]
                              },
                            },
                            {
                              key: "cell(viatura_matricula)",
                              fn: function (data) {
                                return [
                                  _vm._v(
                                    "\n                " +
                                      _vm._s(data.item.viatura.matricula) +
                                      "\n              "
                                  ),
                                ]
                              },
                            },
                            {
                              key: "cell(combustivel)",
                              fn: function (data) {
                                return [
                                  _vm._v(
                                    "\n                " +
                                      _vm._s(
                                        data.item.viatura.tipo_combustivel
                                      ) +
                                      "\n              "
                                  ),
                                ]
                              },
                            },
                            {
                              key: "cell(qtd)",
                              fn: function (data) {
                                return [
                                  _vm._v(
                                    "\n                " +
                                      _vm._s(data.item.qtd_abastecida) +
                                      "\n              "
                                  ),
                                ]
                              },
                            },
                            {
                              key: "cell(preço)",
                              fn: function (data) {
                                return [
                                  _vm._v(
                                    "\n                " +
                                      _vm._s(
                                        _vm._f("toCurrency")(
                                          data.item.preco_cunsumo /
                                            data.item.qtd_abastecida
                                        )
                                      ) +
                                      "\n              "
                                  ),
                                ]
                              },
                            },
                            {
                              key: "cell(rotas_tomadas)",
                              fn: function (data) {
                                return _vm._l(
                                  data.item.ordem_viatura_rota,
                                  function (rotas, i) {
                                    return _c("div", { key: "A" + i }, [
                                      _c("span", { staticClass: "mr-1" }, [
                                        _vm._v(_vm._s(rotas.rota.nome_rota)),
                                      ]),
                                    ])
                                  }
                                )
                              },
                            },
                            {
                              key: "cell(bombas)",
                              fn: function (data) {
                                return [
                                  _vm._v(
                                    "\n                " +
                                      _vm._s(
                                        data.item.ordem.bombas.nome_bombas
                                      ) +
                                      "\n              "
                                  ),
                                ]
                              },
                            },
                            {
                              key: "cell(autor)",
                              fn: function (data) {
                                return [
                                  data.item.ordem.approved_by !== null
                                    ? _c("span", [
                                        _vm._v(
                                          "\n                  " +
                                            _vm._s(
                                              data.item.ordem.approved_by.name
                                            ) +
                                            "\n                  "
                                        ),
                                      ])
                                    : _vm._e(),
                                ]
                              },
                            },
                            {
                              key: "cell(Subtotal)",
                              fn: function (data) {
                                return [
                                  _vm._v(
                                    "\n                " +
                                      _vm._s(
                                        _vm._f("toCurrency")(
                                          data.item.preco_cunsumo
                                        )
                                      ) +
                                      "\n              "
                                  ),
                                ]
                              },
                            },
                            {
                              key: "cell(acção)",
                              fn: function (data) {
                                return [
                                  _c(
                                    "b-dropdown",
                                    {
                                      attrs: {
                                        variant: "link",
                                        "no-caret": "",
                                        right: _vm.$store.state.appConfig.isRTL,
                                      },
                                      scopedSlots: _vm._u(
                                        [
                                          {
                                            key: "button-content",
                                            fn: function () {
                                              return [
                                                _c("feather-icon", {
                                                  staticClass:
                                                    "align-middle text-body",
                                                  attrs: {
                                                    icon: "MoreVerticalIcon",
                                                    size: "16",
                                                  },
                                                }),
                                              ]
                                            },
                                            proxy: true,
                                          },
                                        ],
                                        null,
                                        true
                                      ),
                                    },
                                    [
                                      _vm._v(" "),
                                      _c(
                                        "b-dropdown-item",
                                        {
                                          attrs: {
                                            to: {
                                              name: "supply-details",
                                              params: {
                                                refs: data.item.ordem.refs,
                                              },
                                            },
                                          },
                                        },
                                        [
                                          _c("feather-icon", {
                                            attrs: { icon: "FileTextIcon" },
                                          }),
                                          _vm._v(" "),
                                          _c(
                                            "span",
                                            {
                                              staticClass: "align-middle ml-50",
                                            },
                                            [_vm._v("Details")]
                                          ),
                                        ],
                                        1
                                      ),
                                    ],
                                    1
                                  ),
                                ]
                              },
                            },
                          ]),
                        }),
                        _vm._v(" "),
                        _c(
                          "div",
                          { staticClass: "mx-2 mb-2" },
                          [
                            _c(
                              "b-row",
                              [
                                _c(
                                  "b-col",
                                  {
                                    staticClass:
                                      "\n                    d-flex\n                    align-items-center\n                    justify-content-center justify-content-sm-start\n                  ",
                                    attrs: { cols: "12", sm: "8" },
                                  },
                                  [
                                    _c("span", { staticClass: "text-muted" }, [
                                      _vm._v(
                                        "mostrar " +
                                          _vm._s(_vm.dataHistory.from) +
                                          " de\n                    " +
                                          _vm._s(_vm.dataHistory.to) +
                                          " para\n                    " +
                                          _vm._s(_vm.dataHistory.of) +
                                          " entradas"
                                      ),
                                    ]),
                                  ]
                                ),
                                _vm._v(" "),
                                _c(
                                  "b-col",
                                  {
                                    staticClass:
                                      "\n                    d-flex\n                    align-items-center\n                    justify-content-center justify-content-sm-end\n                  ",
                                    attrs: { cols: "12", sm: "4" },
                                  },
                                  [
                                    _c("b-pagination", {
                                      staticClass: "mb-0 mt-1 mt-sm-0",
                                      attrs: {
                                        "total-rows": _vm.totalHistoricos,
                                        "per-page": _vm.perPage,
                                        "first-number": "",
                                        "last-number": "",
                                        "prev-class": "prev-item",
                                        "next-class": "next-item",
                                      },
                                      scopedSlots: _vm._u([
                                        {
                                          key: "prev-text",
                                          fn: function () {
                                            return [
                                              _c("feather-icon", {
                                                attrs: {
                                                  icon: "ChevronLeftIcon",
                                                  size: "18",
                                                },
                                              }),
                                            ]
                                          },
                                          proxy: true,
                                        },
                                        {
                                          key: "next-text",
                                          fn: function () {
                                            return [
                                              _c("feather-icon", {
                                                attrs: {
                                                  icon: "ChevronRightIcon",
                                                  size: "18",
                                                },
                                              }),
                                            ]
                                          },
                                          proxy: true,
                                        },
                                      ]),
                                      model: {
                                        value: _vm.currentPage,
                                        callback: function ($$v) {
                                          _vm.currentPage = $$v
                                        },
                                        expression: "currentPage",
                                      },
                                    }),
                                  ],
                                  1
                                ),
                              ],
                              1
                            ),
                          ],
                          1
                        ),
                      ],
                      1
                    ),
                  ],
                  1
                ),
              ],
              1
            ),
          ],
          1
        ),
      ],
      1
    ),
  ])
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./resources/js/src/views/Gestao-abastecimentos/abastecimentos/relatorio_geral.vue":
/*!*****************************************************************************************!*\
  !*** ./resources/js/src/views/Gestao-abastecimentos/abastecimentos/relatorio_geral.vue ***!
  \*****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _relatorio_geral_vue_vue_type_template_id_457c7aff___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./relatorio_geral.vue?vue&type=template&id=457c7aff& */ "./resources/js/src/views/Gestao-abastecimentos/abastecimentos/relatorio_geral.vue?vue&type=template&id=457c7aff&");
/* harmony import */ var _relatorio_geral_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./relatorio_geral.vue?vue&type=script&lang=js& */ "./resources/js/src/views/Gestao-abastecimentos/abastecimentos/relatorio_geral.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _relatorio_geral_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _relatorio_geral_vue_vue_type_template_id_457c7aff___WEBPACK_IMPORTED_MODULE_0__["render"],
  _relatorio_geral_vue_vue_type_template_id_457c7aff___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/Gestao-abastecimentos/abastecimentos/relatorio_geral.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/Gestao-abastecimentos/abastecimentos/relatorio_geral.vue?vue&type=script&lang=js&":
/*!******************************************************************************************************************!*\
  !*** ./resources/js/src/views/Gestao-abastecimentos/abastecimentos/relatorio_geral.vue?vue&type=script&lang=js& ***!
  \******************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_relatorio_geral_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./relatorio_geral.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/Gestao-abastecimentos/abastecimentos/relatorio_geral.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_relatorio_geral_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/Gestao-abastecimentos/abastecimentos/relatorio_geral.vue?vue&type=template&id=457c7aff&":
/*!************************************************************************************************************************!*\
  !*** ./resources/js/src/views/Gestao-abastecimentos/abastecimentos/relatorio_geral.vue?vue&type=template&id=457c7aff& ***!
  \************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_relatorio_geral_vue_vue_type_template_id_457c7aff___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./relatorio_geral.vue?vue&type=template&id=457c7aff& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/Gestao-abastecimentos/abastecimentos/relatorio_geral.vue?vue&type=template&id=457c7aff&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_relatorio_geral_vue_vue_type_template_id_457c7aff___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_relatorio_geral_vue_vue_type_template_id_457c7aff___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);