(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[147],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/Gestao-pickete/relatorios/gestao_ocorrencias.vue?vue&type=script&lang=js&":
/*!******************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/Gestao-pickete/relatorios/gestao_ocorrencias.vue?vue&type=script&lang=js& ***!
  \******************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.json.stringify.js */ "./node_modules/core-js/modules/es.json.stringify.js");
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");
/* harmony import */ var vee_validate__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! vee-validate */ "./node_modules/vee-validate/dist/vee-validate.esm.js");
/* harmony import */ var _validations__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @validations */ "./resources/js/src/@core/utils/validations/validations.js");
/* harmony import */ var _core_comp_functions_forms_form_validation__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @core/comp-functions/forms/form-validation */ "./resources/js/src/@core/comp-functions/forms/form-validation.js");
/* harmony import */ var vue_ripple_directive__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! vue-ripple-directive */ "./node_modules/vue-ripple-directive/src/ripple.js");
/* harmony import */ var vue_select__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! vue-select */ "./node_modules/vue-select/dist/vue-select.js");
/* harmony import */ var vue_select__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(vue_select__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _vue_composition_api__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @vue/composition-api */ "./node_modules/@vue/composition-api/dist/vue-composition-api.mjs");
/* harmony import */ var vform__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! vform */ "./node_modules/vform/dist/vform.es.js");
/* harmony import */ var vue_cleave_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! vue-cleave-component */ "./node_modules/vue-cleave-component/dist/vue-cleave.min.js");
/* harmony import */ var vue_cleave_component__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(vue_cleave_component__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var vue2_datepicker__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! vue2-datepicker */ "./node_modules/vue2-datepicker/index.esm.js");
/* harmony import */ var _storeOcorrenciaModules__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./storeOcorrenciaModules */ "./resources/js/src/views/Gestao-pickete/relatorios/storeOcorrenciaModules.js");
/* harmony import */ var _index__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./index */ "./resources/js/src/views/Gestao-pickete/relatorios/index.js");
/* harmony import */ var vue2_datepicker_index_css__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! vue2-datepicker/index.css */ "./node_modules/vue2-datepicker/index.css");
/* harmony import */ var vue2_datepicker_index_css__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(vue2_datepicker_index_css__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var vue_toastification_composition__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! vue-toastification/composition */ "./node_modules/vue-toastification/composition/index.js");
/* harmony import */ var vue_toastification_composition__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(vue_toastification_composition__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _core_components_toastification_ToastificationContent_vue__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @core/components/toastification/ToastificationContent.vue */ "./resources/js/src/@core/components/toastification/ToastificationContent.vue");
/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @/store */ "./resources/js/src/store/index.js");

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
















/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    BCard: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BCard"],
    BRow: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BRow"],
    BCol: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BCol"],
    BFormInput: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BFormInput"],
    BFormInvalidFeedback: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BFormInvalidFeedback"],
    BButton: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BButton"],
    BTable: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BTable"],
    BLink: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BLink"],
    BBadge: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BBadge"],
    BDropdown: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BDropdown"],
    BDropdownItem: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BDropdownItem"],
    BPagination: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BPagination"],
    vSelect: vue_select__WEBPACK_IMPORTED_MODULE_6___default.a,
    BForm: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BForm"],
    BFormGroup: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BFormGroup"],
    BFormTextarea: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BFormTextarea"],
    Cleave: vue_cleave_component__WEBPACK_IMPORTED_MODULE_9___default.a,
    DatePicker: vue2_datepicker__WEBPACK_IMPORTED_MODULE_10__["default"],
    // Form Validation
    ValidationProvider: vee_validate__WEBPACK_IMPORTED_MODULE_2__["ValidationProvider"],
    ValidationObserver: vee_validate__WEBPACK_IMPORTED_MODULE_2__["ValidationObserver"]
  },
  data: function data() {
    return {
      required: _validations__WEBPACK_IMPORTED_MODULE_3__["required"],
      alphaNum: _validations__WEBPACK_IMPORTED_MODULE_3__["alphaNum"],
      email: _validations__WEBPACK_IMPORTED_MODULE_3__["email"],
      viaturas: [],
      motoristas: []
    };
  },
  directives: {
    Ripple: vue_ripple_directive__WEBPACK_IMPORTED_MODULE_5__["default"]
  },
  created: function created() {
    this.listViaturas();
    this.listMotoristas();
  },
  methods: {
    listViaturas: function listViaturas() {
      var _this = this;

      this.$http.get("/api/listAllViaturas").then(function (response) {
        _this.viaturas = response.data;
      });
    },
    listMotoristas: function listMotoristas() {
      var _this2 = this;

      this.$http.get("/api/listMotoristas").then(function (response) {
        _this2.motoristas = response.data;
      });
    }
  },
  setup: function setup(_ref) {
    var emit = _ref.emit;
    var PIQUECT_STORE_MODULE_NAME = "Picket";
    var editMode = false; // Register module

    if (!_store__WEBPACK_IMPORTED_MODULE_16__["default"].hasModule(PIQUECT_STORE_MODULE_NAME)) {
      _store__WEBPACK_IMPORTED_MODULE_16__["default"].registerModule(PIQUECT_STORE_MODULE_NAME, _storeOcorrenciaModules__WEBPACK_IMPORTED_MODULE_11__["default"]);
    } // UnRegister on leave


    Object(_vue_composition_api__WEBPACK_IMPORTED_MODULE_7__["onUnmounted"])(function () {
      if (_store__WEBPACK_IMPORTED_MODULE_16__["default"].hasModule(PIQUECT_STORE_MODULE_NAME)) {
        _store__WEBPACK_IMPORTED_MODULE_16__["default"].unregisterModule(PIQUECT_STORE_MODULE_NAME);
      }
    });
    var statusOptions = [{
      label: "Resolvido",
      value: "Resolvido"
    }, {
      label: "Não Resolvida",
      value: "Não Resolvida"
    }];

    function showModal() {
      this.editMode = false;
      this.$refs["my-modal"].show();
    }

    function toggleModal() {
      this.$refs["my-modal"].toggle("#toggle-btn");
    }

    function onReset(e) {
      e.preventDefault(); // Reset our form values

      this.form.reset();
    }

    var toast = Object(vue_toastification_composition__WEBPACK_IMPORTED_MODULE_14__["useToast"])();
    var form = Object(_vue_composition_api__WEBPACK_IMPORTED_MODULE_7__["ref"])(JSON.parse(JSON.stringify(new vform__WEBPACK_IMPORTED_MODULE_8__["default"]({
      id: "",
      viatura_id: "",
      motorista_id: "",
      descricao_ocorrencia: "",
      hora_da_ocorrencia: "",
      kilometragem: "",
      tipo_ocorrencia: "",
      periodo: "",
      data_ocorrencia: ""
    }))));

    function onSubmit() {
      var _this3 = this;

      this.editMode = false;
      _store__WEBPACK_IMPORTED_MODULE_16__["default"].dispatch("Picket/addOcorrencia", form.value).then(function (response) {
        _this3.$emit("refetch-data");

        toast({
          component: _core_components_toastification_ToastificationContent_vue__WEBPACK_IMPORTED_MODULE_15__["default"],
          props: {
            title: response.data.message,
            icon: "CheckSquareIcon",
            variant: "success"
          }
        });

        _this3.toggleModal();
      })["catch"](function (err) {
        console.log(err);

        if (err) {
          toast({
            component: _core_components_toastification_ToastificationContent_vue__WEBPACK_IMPORTED_MODULE_15__["default"],
            props: {
              title: err.response.data.error,
              icon: "AlertTriangleIcon",
              variant: "danger"
            }
          });
        }
      });
    }

    var _formValidation = Object(_core_comp_functions_forms_form_validation__WEBPACK_IMPORTED_MODULE_4__["default"])(form),
        refFormObserver = _formValidation.refFormObserver,
        getValidationState = _formValidation.getValidationState;

    var options = {
      time: {
        time: true,
        timePattern: ['h', 'm', 's']
      }
    };

    var _OcorrenciasList = Object(_index__WEBPACK_IMPORTED_MODULE_12__["default"])(),
        fetchOcorrencias = _OcorrenciasList.fetchOcorrencias,
        tableColumns = _OcorrenciasList.tableColumns,
        perPage = _OcorrenciasList.perPage,
        currentPage = _OcorrenciasList.currentPage,
        totalOcorrencias = _OcorrenciasList.totalOcorrencias,
        dataMeta = _OcorrenciasList.dataMeta,
        perPageOptions = _OcorrenciasList.perPageOptions,
        searchQuery = _OcorrenciasList.searchQuery,
        sortBy = _OcorrenciasList.sortBy,
        isSortDirDesc = _OcorrenciasList.isSortDirDesc,
        refOcorrenciaListTable = _OcorrenciasList.refOcorrenciaListTable,
        refetchData = _OcorrenciasList.refetchData,
        statusFilter = _OcorrenciasList.statusFilter;

    return {
      // Sidebar
      fetchOcorrencias: fetchOcorrencias,
      tableColumns: tableColumns,
      perPage: perPage,
      currentPage: currentPage,
      totalOcorrencias: totalOcorrencias,
      dataMeta: dataMeta,
      perPageOptions: perPageOptions,
      searchQuery: searchQuery,
      sortBy: sortBy,
      isSortDirDesc: isSortDirDesc,
      refOcorrenciaListTable: refOcorrenciaListTable,
      refetchData: refetchData,
      showModal: showModal,
      toggleModal: toggleModal,
      onReset: onReset,
      form: form,
      onSubmit: onSubmit,
      statusOptions: statusOptions,
      options: options,
      // Extra Filters
      statusFilter: statusFilter,
      refFormObserver: refFormObserver,
      getValidationState: getValidationState
    };
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/Gestao-pickete/relatorios/gestao_ocorrencias.vue?vue&type=template&id=411f114b&":
/*!**********************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/Gestao-pickete/relatorios/gestao_ocorrencias.vue?vue&type=template&id=411f114b& ***!
  \**********************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "b-card",
    { staticClass: "mb-0", attrs: { "no-body": "" } },
    [
      _c(
        "div",
        { staticClass: "m-2" },
        [
          _c(
            "b-row",
            [
              _c(
                "b-col",
                {
                  staticClass:
                    "d-flex align-items-center justify-content-start mb-1 mb-md-0",
                  attrs: { cols: "12", md: "6" },
                },
                [
                  _c("label", [_vm._v("Show")]),
                  _vm._v(" "),
                  _c("v-select", {
                    staticClass: "per-page-selector d-inline-block mx-50",
                    attrs: {
                      dir: _vm.$store.state.appConfig.isRTL ? "rtl" : "ltr",
                      options: _vm.perPageOptions,
                      clearable: false,
                    },
                    model: {
                      value: _vm.perPage,
                      callback: function ($$v) {
                        _vm.perPage = $$v
                      },
                      expression: "perPage",
                    },
                  }),
                  _vm._v(" "),
                  _c("label", [_vm._v("entries")]),
                ],
                1
              ),
              _vm._v(" "),
              _c("b-col", { attrs: { cols: "12", md: "6" } }, [
                _c(
                  "div",
                  {
                    staticClass:
                      "d-flex align-items-center justify-content-end",
                  },
                  [
                    _c("b-form-input", {
                      staticClass: "d-inline-block mr-1",
                      attrs: { placeholder: "Search..." },
                      model: {
                        value: _vm.searchQuery,
                        callback: function ($$v) {
                          _vm.searchQuery = $$v
                        },
                        expression: "searchQuery",
                      },
                    }),
                    _vm._v(" "),
                    _c(
                      "b-link",
                      {
                        staticClass: "btn btn-outline-primary",
                        on: { click: _vm.showModal },
                      },
                      [
                        _c("span", { staticClass: "text-nowrap" }, [
                          _vm._v("Ad.ocorrencia"),
                        ]),
                      ]
                    ),
                  ],
                  1
                ),
              ]),
            ],
            1
          ),
        ],
        1
      ),
      _vm._v(" "),
      _c("b-table", {
        ref: "refOcorrenciaListTable",
        staticClass: "position-relative",
        attrs: {
          items: _vm.fetchOcorrencias,
          responsive: "",
          fields: _vm.tableColumns,
          "primary-key": "id",
          "sort-by": _vm.sortBy,
          "show-empty": "",
          "empty-text": "No matching records found",
          "sort-desc": _vm.isSortDirDesc,
        },
        on: {
          "update:sortBy": function ($event) {
            _vm.sortBy = $event
          },
          "update:sort-by": function ($event) {
            _vm.sortBy = $event
          },
          "update:sortDesc": function ($event) {
            _vm.isSortDirDesc = $event
          },
          "update:sort-desc": function ($event) {
            _vm.isSortDirDesc = $event
          },
        },
        scopedSlots: _vm._u([
          {
            key: "cell(Data)",
            fn: function (data) {
              return [
                _vm._v("\n      " + _vm._s(data.item.data_ocorrencia) + "\n  "),
              ]
            },
          },
          {
            key: "cell(Hora)",
            fn: function (data) {
              return [
                _vm._v(
                  "\n      " + _vm._s(data.item.hora_da_ocorrencia) + "\n  "
                ),
              ]
            },
          },
          {
            key: "cell(Desrição)",
            fn: function (data) {
              return [
                _vm._v(
                  "\n      " + _vm._s(data.item.descricao_ocorrencia) + "\n  "
                ),
              ]
            },
          },
          {
            key: "cell(actions)",
            fn: function (data) {
              return [
                _c(
                  "b-dropdown",
                  {
                    attrs: {
                      variant: "link",
                      "no-caret": "",
                      right: _vm.$store.state.appConfig.isRTL,
                    },
                    scopedSlots: _vm._u(
                      [
                        {
                          key: "button-content",
                          fn: function () {
                            return [
                              _c("feather-icon", {
                                staticClass: "align-middle text-body",
                                attrs: { icon: "MoreVerticalIcon", size: "16" },
                              }),
                            ]
                          },
                          proxy: true,
                        },
                      ],
                      null,
                      true
                    ),
                  },
                  [
                    _vm._v(" "),
                    _c(
                      "b-dropdown-item",
                      {
                        attrs: {
                          to: {
                            name: "Occurrence-details",
                            params: { id: data.item.id },
                          },
                        },
                      },
                      [
                        _c("feather-icon", { attrs: { icon: "FileTextIcon" } }),
                        _vm._v(" "),
                        _c("span", { staticClass: "align-middle ml-50" }, [
                          _vm._v("Detalhes"),
                        ]),
                      ],
                      1
                    ),
                  ],
                  1
                ),
              ]
            },
          },
        ]),
      }),
      _vm._v(" "),
      _c(
        "div",
        { staticClass: "mx-2 mb-2" },
        [
          _c(
            "b-row",
            [
              _c(
                "b-col",
                {
                  staticClass:
                    "\n          d-flex\n          align-items-center\n          justify-content-center justify-content-sm-start\n        ",
                  attrs: { cols: "12", sm: "6" },
                },
                [
                  _c("span", { staticClass: "text-muted" }, [
                    _vm._v(
                      "Showing " +
                        _vm._s(_vm.dataMeta.from) +
                        " to " +
                        _vm._s(_vm.dataMeta.to) +
                        " of\n          " +
                        _vm._s(_vm.dataMeta.of) +
                        " entries"
                    ),
                  ]),
                ]
              ),
              _vm._v(" "),
              _c(
                "b-col",
                {
                  staticClass:
                    "\n          d-flex\n          align-items-center\n          justify-content-center justify-content-sm-end\n        ",
                  attrs: { cols: "12", sm: "6" },
                },
                [
                  _c("b-pagination", {
                    staticClass: "mb-0 mt-1 mt-sm-0",
                    attrs: {
                      "total-rows": _vm.totalOcorrencias,
                      "per-page": _vm.perPage,
                      "first-number": "",
                      "last-number": "",
                      "prev-class": "prev-item",
                      "next-class": "next-item",
                    },
                    scopedSlots: _vm._u([
                      {
                        key: "prev-text",
                        fn: function () {
                          return [
                            _c("feather-icon", {
                              attrs: { icon: "ChevronLeftIcon", size: "18" },
                            }),
                          ]
                        },
                        proxy: true,
                      },
                      {
                        key: "next-text",
                        fn: function () {
                          return [
                            _c("feather-icon", {
                              attrs: { icon: "ChevronRightIcon", size: "18" },
                            }),
                          ]
                        },
                        proxy: true,
                      },
                    ]),
                    model: {
                      value: _vm.currentPage,
                      callback: function ($$v) {
                        _vm.currentPage = $$v
                      },
                      expression: "currentPage",
                    },
                  }),
                ],
                1
              ),
            ],
            1
          ),
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "b-modal",
        {
          ref: "my-modal",
          attrs: { size: "lg", "hide-footer": "", title: "Nova ocorrencia" },
        },
        [
          _c("validation-observer", {
            ref: "refFormObserver",
            scopedSlots: _vm._u([
              {
                key: "default",
                fn: function (ref) {
                  var handleSubmit = ref.handleSubmit
                  return [
                    _c(
                      "b-form",
                      {
                        on: {
                          submit: function ($event) {
                            $event.preventDefault()
                            return handleSubmit(_vm.onSubmit)
                          },
                          reset: _vm.onReset,
                        },
                      },
                      [
                        _c(
                          "b-row",
                          [
                            _c("input", {
                              directives: [
                                {
                                  name: "model",
                                  rawName: "v-model",
                                  value: _vm.form.id,
                                  expression: "form.id",
                                },
                              ],
                              attrs: { type: "hidden" },
                              domProps: { value: _vm.form.id },
                              on: {
                                input: function ($event) {
                                  if ($event.target.composing) {
                                    return
                                  }
                                  _vm.$set(_vm.form, "id", $event.target.value)
                                },
                              },
                            }),
                            _vm._v(" "),
                            _c(
                              "b-col",
                              { attrs: { cols: "12", md: "6", lg: "6" } },
                              [
                                _c("validation-provider", {
                                  attrs: { name: "viatura", rules: "required" },
                                  scopedSlots: _vm._u(
                                    [
                                      {
                                        key: "default",
                                        fn: function (validationContext) {
                                          return [
                                            _c(
                                              "b-form-group",
                                              {
                                                attrs: {
                                                  label: "viatura",
                                                  state:
                                                    _vm.getValidationState(
                                                      validationContext
                                                    ),
                                                },
                                              },
                                              [
                                                _c("v-select", {
                                                  attrs: {
                                                    label: "matricula",
                                                    options: _vm.viaturas,
                                                    reduce: function (
                                                      viaturas
                                                    ) {
                                                      return viaturas.id
                                                    },
                                                  },
                                                  model: {
                                                    value: _vm.form.viatura_id,
                                                    callback: function ($$v) {
                                                      _vm.$set(
                                                        _vm.form,
                                                        "viatura_id",
                                                        $$v
                                                      )
                                                    },
                                                    expression:
                                                      "form.viatura_id",
                                                  },
                                                }),
                                                _vm._v(" "),
                                                _c("b-form-invalid-feedback", [
                                                  _vm._v(
                                                    "\n                  " +
                                                      _vm._s(
                                                        validationContext
                                                          .errors[0]
                                                      ) +
                                                      "\n                "
                                                  ),
                                                ]),
                                              ],
                                              1
                                            ),
                                          ]
                                        },
                                      },
                                    ],
                                    null,
                                    true
                                  ),
                                }),
                              ],
                              1
                            ),
                            _vm._v(" "),
                            _c(
                              "b-col",
                              { attrs: { cols: "12", md: "6", lg: "6" } },
                              [
                                _c("validation-provider", {
                                  attrs: {
                                    name: "motorista",
                                    rules: "required",
                                  },
                                  scopedSlots: _vm._u(
                                    [
                                      {
                                        key: "default",
                                        fn: function (validationContext) {
                                          return [
                                            _c(
                                              "b-form-group",
                                              { attrs: { label: "motorista" } },
                                              [
                                                _c("v-select", {
                                                  attrs: {
                                                    label: "nome",
                                                    options: _vm.motoristas,
                                                    reduce: function (
                                                      motoristas
                                                    ) {
                                                      return motoristas.id
                                                    },
                                                  },
                                                  model: {
                                                    value:
                                                      _vm.form.motorista_id,
                                                    callback: function ($$v) {
                                                      _vm.$set(
                                                        _vm.form,
                                                        "motorista_id",
                                                        $$v
                                                      )
                                                    },
                                                    expression:
                                                      "form.motorista_id",
                                                  },
                                                }),
                                                _vm._v(" "),
                                                _c("b-form-invalid-feedback", [
                                                  _vm._v(
                                                    "\n                  " +
                                                      _vm._s(
                                                        validationContext
                                                          .errors[0]
                                                      ) +
                                                      "\n                "
                                                  ),
                                                ]),
                                              ],
                                              1
                                            ),
                                          ]
                                        },
                                      },
                                    ],
                                    null,
                                    true
                                  ),
                                }),
                              ],
                              1
                            ),
                            _vm._v(" "),
                            _c(
                              "b-col",
                              { attrs: { cols: "12", md: "6", lg: "6" } },
                              [
                                _c("validation-provider", {
                                  attrs: {
                                    name: "data da ocorrencia",
                                    rules: "required",
                                  },
                                  scopedSlots: _vm._u(
                                    [
                                      {
                                        key: "default",
                                        fn: function (validationContext) {
                                          return [
                                            _c(
                                              "b-form-group",
                                              {
                                                attrs: {
                                                  label: "data da ocorrencia:",
                                                },
                                              },
                                              [
                                                _c("date-picker", {
                                                  staticStyle: {
                                                    width: "100%",
                                                  },
                                                  attrs: {
                                                    "value-type": "format",
                                                    format: "YYYY-MM-DD",
                                                    state:
                                                      _vm.getValidationState(
                                                        validationContext
                                                      ),
                                                    trim: "",
                                                  },
                                                  model: {
                                                    value:
                                                      _vm.form.data_ocorrencia,
                                                    callback: function ($$v) {
                                                      _vm.$set(
                                                        _vm.form,
                                                        "data_ocorrencia",
                                                        $$v
                                                      )
                                                    },
                                                    expression:
                                                      "form.data_ocorrencia",
                                                  },
                                                }),
                                                _vm._v(" "),
                                                _c("b-form-invalid-feedback", [
                                                  _vm._v(
                                                    "\n                  " +
                                                      _vm._s(
                                                        validationContext
                                                          .errors[0]
                                                      ) +
                                                      "\n                "
                                                  ),
                                                ]),
                                              ],
                                              1
                                            ),
                                          ]
                                        },
                                      },
                                    ],
                                    null,
                                    true
                                  ),
                                }),
                              ],
                              1
                            ),
                            _vm._v(" "),
                            _c(
                              "b-col",
                              { attrs: { cols: "12", md: "6", lg: "6" } },
                              [
                                _c("validation-provider", {
                                  attrs: { name: "hora", rules: "required" },
                                  scopedSlots: _vm._u(
                                    [
                                      {
                                        key: "default",
                                        fn: function (validationContext) {
                                          return [
                                            _c(
                                              "b-form-group",
                                              { attrs: { label: "hora" } },
                                              [
                                                _c("cleave", {
                                                  staticClass: "form-control",
                                                  attrs: {
                                                    id: "time",
                                                    raw: false,
                                                    options: _vm.options.time,
                                                    placeholder: "hh:mm:ss",
                                                    state:
                                                      _vm.getValidationState(
                                                        validationContext
                                                      ),
                                                    trim: "",
                                                  },
                                                  model: {
                                                    value:
                                                      _vm.form
                                                        .hora_da_ocorrencia,
                                                    callback: function ($$v) {
                                                      _vm.$set(
                                                        _vm.form,
                                                        "hora_da_ocorrencia",
                                                        $$v
                                                      )
                                                    },
                                                    expression:
                                                      "form.hora_da_ocorrencia",
                                                  },
                                                }),
                                                _vm._v(" "),
                                                _c("b-form-invalid-feedback", [
                                                  _vm._v(
                                                    "\n                  " +
                                                      _vm._s(
                                                        validationContext
                                                          .errors[0]
                                                      ) +
                                                      "\n                "
                                                  ),
                                                ]),
                                              ],
                                              1
                                            ),
                                          ]
                                        },
                                      },
                                    ],
                                    null,
                                    true
                                  ),
                                }),
                              ],
                              1
                            ),
                            _vm._v(" "),
                            _c(
                              "b-col",
                              { attrs: { cols: "12", md: "6", lg: "6" } },
                              [
                                _c("validation-provider", {
                                  attrs: {
                                    name: "periodo da ocorrencia",
                                    rules: "required",
                                  },
                                  scopedSlots: _vm._u(
                                    [
                                      {
                                        key: "default",
                                        fn: function (validationContext) {
                                          return [
                                            _c(
                                              "b-form-group",
                                              {
                                                attrs: {
                                                  label:
                                                    "periodo da ocorrencia",
                                                  state:
                                                    _vm.getValidationState(
                                                      validationContext
                                                    ),
                                                },
                                              },
                                              [
                                                _c("v-select", {
                                                  attrs: {
                                                    options: [
                                                      "Diurno",
                                                      "Noturno",
                                                    ],
                                                    trim: "",
                                                  },
                                                  model: {
                                                    value: _vm.form.periodo,
                                                    callback: function ($$v) {
                                                      _vm.$set(
                                                        _vm.form,
                                                        "periodo",
                                                        $$v
                                                      )
                                                    },
                                                    expression: "form.periodo",
                                                  },
                                                }),
                                                _vm._v(" "),
                                                _c("b-form-invalid-feedback", [
                                                  _vm._v(
                                                    "\n                  " +
                                                      _vm._s(
                                                        validationContext
                                                          .errors[0]
                                                      ) +
                                                      "\n                "
                                                  ),
                                                ]),
                                              ],
                                              1
                                            ),
                                          ]
                                        },
                                      },
                                    ],
                                    null,
                                    true
                                  ),
                                }),
                              ],
                              1
                            ),
                            _vm._v(" "),
                            _c(
                              "b-col",
                              { attrs: { cols: "12", md: "6", lg: "6" } },
                              [
                                _c("validation-provider", {
                                  attrs: {
                                    name: "kilometragem actual da viatura",
                                    rules: "required",
                                  },
                                  scopedSlots: _vm._u(
                                    [
                                      {
                                        key: "default",
                                        fn: function (validationContext) {
                                          return [
                                            _c(
                                              "b-form-group",
                                              {
                                                attrs: {
                                                  label:
                                                    "kilometragem actual da viatura",
                                                },
                                              },
                                              [
                                                _c("b-form-input", {
                                                  attrs: {
                                                    type: "number",
                                                    state:
                                                      _vm.getValidationState(
                                                        validationContext
                                                      ),
                                                    trim: "",
                                                  },
                                                  model: {
                                                    value:
                                                      _vm.form.kilometragem,
                                                    callback: function ($$v) {
                                                      _vm.$set(
                                                        _vm.form,
                                                        "kilometragem",
                                                        $$v
                                                      )
                                                    },
                                                    expression:
                                                      "form.kilometragem",
                                                  },
                                                }),
                                                _vm._v(" "),
                                                _c("b-form-invalid-feedback", [
                                                  _vm._v(
                                                    "\n                  " +
                                                      _vm._s(
                                                        validationContext
                                                          .errors[0]
                                                      ) +
                                                      "\n                "
                                                  ),
                                                ]),
                                              ],
                                              1
                                            ),
                                          ]
                                        },
                                      },
                                    ],
                                    null,
                                    true
                                  ),
                                }),
                              ],
                              1
                            ),
                            _vm._v(" "),
                            _c(
                              "b-col",
                              { attrs: { cols: "12", md: "6", lg: "6" } },
                              [
                                _c("validation-provider", {
                                  attrs: {
                                    name: "tipo de ocorrencia",
                                    rules: "required",
                                  },
                                  scopedSlots: _vm._u(
                                    [
                                      {
                                        key: "default",
                                        fn: function (validationContext) {
                                          return [
                                            _c(
                                              "b-form-group",
                                              {
                                                attrs: {
                                                  label: "tipo de ocorrencia",
                                                  state:
                                                    _vm.getValidationState(
                                                      validationContext
                                                    ),
                                                },
                                              },
                                              [
                                                _c("v-select", {
                                                  attrs: {
                                                    options: [
                                                      "Informativa",
                                                      "Necessita reparacao",
                                                    ],
                                                    trim: "",
                                                  },
                                                  model: {
                                                    value:
                                                      _vm.form.tipo_ocorrencia,
                                                    callback: function ($$v) {
                                                      _vm.$set(
                                                        _vm.form,
                                                        "tipo_ocorrencia",
                                                        $$v
                                                      )
                                                    },
                                                    expression:
                                                      "form.tipo_ocorrencia",
                                                  },
                                                }),
                                                _vm._v(" "),
                                                _c("b-form-invalid-feedback", [
                                                  _vm._v(
                                                    "\n                  " +
                                                      _vm._s(
                                                        validationContext
                                                          .errors[0]
                                                      ) +
                                                      "\n                "
                                                  ),
                                                ]),
                                              ],
                                              1
                                            ),
                                          ]
                                        },
                                      },
                                    ],
                                    null,
                                    true
                                  ),
                                }),
                              ],
                              1
                            ),
                            _vm._v(" "),
                            _c(
                              "b-col",
                              { attrs: { cols: "12", md: "12", lg: "12" } },
                              [
                                _c("validation-provider", {
                                  attrs: {
                                    name: "descricao",
                                    rules: "required",
                                  },
                                  scopedSlots: _vm._u(
                                    [
                                      {
                                        key: "default",
                                        fn: function (validationContext) {
                                          return [
                                            _c(
                                              "b-form-group",
                                              { attrs: { label: "descricao" } },
                                              [
                                                _c("b-form-textarea", {
                                                  attrs: {
                                                    id: "textarea",
                                                    placeholder:
                                                      "Faça o Relato dos factos",
                                                    state:
                                                      _vm.getValidationState(
                                                        validationContext
                                                      ),
                                                    trim: "",
                                                  },
                                                  model: {
                                                    value:
                                                      _vm.form
                                                        .descricao_ocorrencia,
                                                    callback: function ($$v) {
                                                      _vm.$set(
                                                        _vm.form,
                                                        "descricao_ocorrencia",
                                                        $$v
                                                      )
                                                    },
                                                    expression:
                                                      "form.descricao_ocorrencia",
                                                  },
                                                }),
                                                _vm._v(" "),
                                                _c("b-form-invalid-feedback", [
                                                  _vm._v(
                                                    "\n                  " +
                                                      _vm._s(
                                                        validationContext
                                                          .errors[0]
                                                      ) +
                                                      "\n                "
                                                  ),
                                                ]),
                                              ],
                                              1
                                            ),
                                          ]
                                        },
                                      },
                                    ],
                                    null,
                                    true
                                  ),
                                }),
                              ],
                              1
                            ),
                            _vm._v(" "),
                            _c(
                              "b-col",
                              { attrs: { cols: "12", md: "6", lg: "6" } },
                              [
                                _c(
                                  "b-button",
                                  {
                                    attrs: {
                                      type: "submit",
                                      variant: "outline-success",
                                    },
                                  },
                                  [_vm._v("emitir ocorrência")]
                                ),
                              ],
                              1
                            ),
                          ],
                          1
                        ),
                      ],
                      1
                    ),
                  ]
                },
              },
            ]),
          }),
          _vm._v(" "),
          _c(
            "b-row",
            [
              _c(
                "b-col",
                { attrs: { cols: "12", md: "12", lg: "12" } },
                [
                  _c(
                    "b-button",
                    {
                      staticClass: "float-right",
                      attrs: { variant: "outline-warning" },
                      on: { click: _vm.toggleModal },
                    },
                    [_vm._v("\n          fechar\n        ")]
                  ),
                ],
                1
              ),
            ],
            1
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./resources/js/src/views/Gestao-pickete/relatorios/gestao_ocorrencias.vue":
/*!*********************************************************************************!*\
  !*** ./resources/js/src/views/Gestao-pickete/relatorios/gestao_ocorrencias.vue ***!
  \*********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _gestao_ocorrencias_vue_vue_type_template_id_411f114b___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./gestao_ocorrencias.vue?vue&type=template&id=411f114b& */ "./resources/js/src/views/Gestao-pickete/relatorios/gestao_ocorrencias.vue?vue&type=template&id=411f114b&");
/* harmony import */ var _gestao_ocorrencias_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./gestao_ocorrencias.vue?vue&type=script&lang=js& */ "./resources/js/src/views/Gestao-pickete/relatorios/gestao_ocorrencias.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _gestao_ocorrencias_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _gestao_ocorrencias_vue_vue_type_template_id_411f114b___WEBPACK_IMPORTED_MODULE_0__["render"],
  _gestao_ocorrencias_vue_vue_type_template_id_411f114b___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/Gestao-pickete/relatorios/gestao_ocorrencias.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/Gestao-pickete/relatorios/gestao_ocorrencias.vue?vue&type=script&lang=js&":
/*!**********************************************************************************************************!*\
  !*** ./resources/js/src/views/Gestao-pickete/relatorios/gestao_ocorrencias.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_gestao_ocorrencias_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./gestao_ocorrencias.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/Gestao-pickete/relatorios/gestao_ocorrencias.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_gestao_ocorrencias_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/Gestao-pickete/relatorios/gestao_ocorrencias.vue?vue&type=template&id=411f114b&":
/*!****************************************************************************************************************!*\
  !*** ./resources/js/src/views/Gestao-pickete/relatorios/gestao_ocorrencias.vue?vue&type=template&id=411f114b& ***!
  \****************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_gestao_ocorrencias_vue_vue_type_template_id_411f114b___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../node_modules/vue-loader/lib??vue-loader-options!./gestao_ocorrencias.vue?vue&type=template&id=411f114b& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/Gestao-pickete/relatorios/gestao_ocorrencias.vue?vue&type=template&id=411f114b&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_gestao_ocorrencias_vue_vue_type_template_id_411f114b___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_gestao_ocorrencias_vue_vue_type_template_id_411f114b___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);