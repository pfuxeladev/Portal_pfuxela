(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[37],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/forms/form-element/form-textarea/FormTextArea.vue?vue&type=script&lang=js&":
/*!*******************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/forms/form-element/form-textarea/FormTextArea.vue?vue&type=script&lang=js& ***!
  \*******************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");
/* harmony import */ var _FormTextAreaDefault_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./FormTextAreaDefault.vue */ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaDefault.vue");
/* harmony import */ var _FormTextAreaRows_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./FormTextAreaRows.vue */ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaRows.vue");
/* harmony import */ var _FormTextAreaFloatingLabel_vue__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./FormTextAreaFloatingLabel.vue */ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaFloatingLabel.vue");
/* harmony import */ var _FormTextAreaStates_vue__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./FormTextAreaStates.vue */ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaStates.vue");
/* harmony import */ var _FormTextAreaSize_vue__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./FormTextAreaSize.vue */ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaSize.vue");
/* harmony import */ var _FormTextAreaDisableResize_vue__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./FormTextAreaDisableResize.vue */ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaDisableResize.vue");
/* harmony import */ var _FormTextAreaAutoHeight_vue__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./FormTextAreaAutoHeight.vue */ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaAutoHeight.vue");
/* harmony import */ var _FormTextAreaFormatter_vue__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./FormTextAreaFormatter.vue */ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaFormatter.vue");
/* harmony import */ var _FormTextAreaReadonly_vue__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./FormTextAreaReadonly.vue */ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaReadonly.vue");
/* harmony import */ var _FormTextAreaDebounce_vue__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./FormTextAreaDebounce.vue */ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaDebounce.vue");
/* harmony import */ var _FormTextAreaCounter_vue__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./FormTextAreaCounter.vue */ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaCounter.vue");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//












/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    BRow: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BRow"],
    BCol: bootstrap_vue__WEBPACK_IMPORTED_MODULE_0__["BCol"],
    FormTextAreaDefault: _FormTextAreaDefault_vue__WEBPACK_IMPORTED_MODULE_1__["default"],
    FormTextAreaRows: _FormTextAreaRows_vue__WEBPACK_IMPORTED_MODULE_2__["default"],
    FormTextAreaFloatingLabel: _FormTextAreaFloatingLabel_vue__WEBPACK_IMPORTED_MODULE_3__["default"],
    FormTextAreaStates: _FormTextAreaStates_vue__WEBPACK_IMPORTED_MODULE_4__["default"],
    FormTextAreaSize: _FormTextAreaSize_vue__WEBPACK_IMPORTED_MODULE_5__["default"],
    FormTextAreaDisableResize: _FormTextAreaDisableResize_vue__WEBPACK_IMPORTED_MODULE_6__["default"],
    FormTextAreaAutoHeight: _FormTextAreaAutoHeight_vue__WEBPACK_IMPORTED_MODULE_7__["default"],
    FormatterTextArea: _FormTextAreaFormatter_vue__WEBPACK_IMPORTED_MODULE_8__["default"],
    FormTextAreaReadonly: _FormTextAreaReadonly_vue__WEBPACK_IMPORTED_MODULE_9__["default"],
    FormTextAreaDebounce: _FormTextAreaDebounce_vue__WEBPACK_IMPORTED_MODULE_10__["default"],
    FormTextAreaCounter: _FormTextAreaCounter_vue__WEBPACK_IMPORTED_MODULE_11__["default"]
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaAutoHeight.vue?vue&type=script&lang=js&":
/*!*****************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaAutoHeight.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _core_components_b_card_code__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @core/components/b-card-code */ "./resources/js/src/@core/components/b-card-code/index.js");
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");
/* harmony import */ var _code__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./code */ "./resources/js/src/views/forms/form-element/form-textarea/code.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//



/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    BCardCode: _core_components_b_card_code__WEBPACK_IMPORTED_MODULE_0__["default"],
    BCardText: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BCardText"],
    BFormTextarea: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BFormTextarea"],
    BRow: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BRow"],
    BCol: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BCol"]
  },
  data: function data() {
    return {
      codeAutoHeight: _code__WEBPACK_IMPORTED_MODULE_2__["codeAutoHeight"]
    };
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaCounter.vue?vue&type=script&lang=js&":
/*!**************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaCounter.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _core_components_b_card_code__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @core/components/b-card-code */ "./resources/js/src/@core/components/b-card-code/index.js");
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");
/* harmony import */ var _code__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./code */ "./resources/js/src/views/forms/form-element/form-textarea/code.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//



/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    BCardCode: _core_components_b_card_code__WEBPACK_IMPORTED_MODULE_0__["default"],
    BCardText: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BCardText"],
    BFormTextarea: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BFormTextarea"]
  },
  data: function data() {
    return {
      value: '',
      maxChar: 20,
      codeCounter: _code__WEBPACK_IMPORTED_MODULE_2__["codeCounter"]
    };
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaDebounce.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaDebounce.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _core_components_b_card_code__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @core/components/b-card-code */ "./resources/js/src/@core/components/b-card-code/index.js");
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");
/* harmony import */ var _code__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./code */ "./resources/js/src/views/forms/form-element/form-textarea/code.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//



/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    BCardCode: _core_components_b_card_code__WEBPACK_IMPORTED_MODULE_0__["default"],
    BFormTextarea: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BFormTextarea"],
    BCardText: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BCardText"]
  },
  data: function data() {
    return {
      value: '',
      codeDebounce: _code__WEBPACK_IMPORTED_MODULE_2__["codeDebounce"]
    };
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaDefault.vue?vue&type=script&lang=js&":
/*!**************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaDefault.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _core_components_b_card_code__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @core/components/b-card-code */ "./resources/js/src/@core/components/b-card-code/index.js");
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");
/* harmony import */ var _code__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./code */ "./resources/js/src/views/forms/form-element/form-textarea/code.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//



/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    BCardCode: _core_components_b_card_code__WEBPACK_IMPORTED_MODULE_0__["default"],
    BCardText: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BCardText"],
    BFormTextarea: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BFormTextarea"]
  },
  data: function data() {
    return {
      codeDefault: _code__WEBPACK_IMPORTED_MODULE_2__["codeDefault"]
    };
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaDisableResize.vue?vue&type=script&lang=js&":
/*!********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaDisableResize.vue?vue&type=script&lang=js& ***!
  \********************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _core_components_b_card_code__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @core/components/b-card-code */ "./resources/js/src/@core/components/b-card-code/index.js");
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");
/* harmony import */ var _code__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./code */ "./resources/js/src/views/forms/form-element/form-textarea/code.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//



/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    BCardCode: _core_components_b_card_code__WEBPACK_IMPORTED_MODULE_0__["default"],
    BFormTextarea: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BFormTextarea"],
    BCardText: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BCardText"]
  },
  data: function data() {
    return {
      codeDisableResize: _code__WEBPACK_IMPORTED_MODULE_2__["codeDisableResize"]
    };
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaFloatingLabel.vue?vue&type=script&lang=js&":
/*!********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaFloatingLabel.vue?vue&type=script&lang=js& ***!
  \********************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _core_components_b_card_code__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @core/components/b-card-code */ "./resources/js/src/@core/components/b-card-code/index.js");
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");
/* harmony import */ var _code__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./code */ "./resources/js/src/views/forms/form-element/form-textarea/code.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//



/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    BCardCode: _core_components_b_card_code__WEBPACK_IMPORTED_MODULE_0__["default"],
    BCardText: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BCardText"],
    BFormTextarea: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BFormTextarea"]
  },
  data: function data() {
    return {
      codeFloatingLabel: _code__WEBPACK_IMPORTED_MODULE_2__["codeFloatingLabel"]
    };
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaFormatter.vue?vue&type=script&lang=js&":
/*!****************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaFormatter.vue?vue&type=script&lang=js& ***!
  \****************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _core_components_b_card_code__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @core/components/b-card-code */ "./resources/js/src/@core/components/b-card-code/index.js");
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");
/* harmony import */ var _code__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./code */ "./resources/js/src/views/forms/form-element/form-textarea/code.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//



/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    BCardCode: _core_components_b_card_code__WEBPACK_IMPORTED_MODULE_0__["default"],
    BFormTextarea: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BFormTextarea"],
    BCardText: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BCardText"],
    BFormGroup: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BFormGroup"]
  },
  data: function data() {
    return {
      text1: '',
      text2: '',
      codeFormatter: _code__WEBPACK_IMPORTED_MODULE_2__["codeFormatter"]
    };
  },
  methods: {
    formatter: function formatter(value) {
      return value.toLowerCase();
    }
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaReadonly.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaReadonly.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _core_components_b_card_code__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @core/components/b-card-code */ "./resources/js/src/@core/components/b-card-code/index.js");
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");
/* harmony import */ var _code__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./code */ "./resources/js/src/views/forms/form-element/form-textarea/code.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//



/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    BCardCode: _core_components_b_card_code__WEBPACK_IMPORTED_MODULE_0__["default"],
    BFormTextarea: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BFormTextarea"],
    BCardText: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BCardText"]
  },
  data: function data() {
    return {
      text: "This is some text.\nIt is read only and doesn't look like an input.",
      codeReadonly: _code__WEBPACK_IMPORTED_MODULE_2__["codeReadonly"]
    };
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaRows.vue?vue&type=script&lang=js&":
/*!***********************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaRows.vue?vue&type=script&lang=js& ***!
  \***********************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _core_components_b_card_code__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @core/components/b-card-code */ "./resources/js/src/@core/components/b-card-code/index.js");
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");
/* harmony import */ var _code__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./code */ "./resources/js/src/views/forms/form-element/form-textarea/code.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//



/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    BCardCode: _core_components_b_card_code__WEBPACK_IMPORTED_MODULE_0__["default"],
    BFormTextarea: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BFormTextarea"],
    BCardText: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BCardText"]
  },
  data: function data() {
    return {
      codeRows: _code__WEBPACK_IMPORTED_MODULE_2__["codeRows"]
    };
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaSize.vue?vue&type=script&lang=js&":
/*!***********************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaSize.vue?vue&type=script&lang=js& ***!
  \***********************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _core_components_b_card_code__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @core/components/b-card-code */ "./resources/js/src/@core/components/b-card-code/index.js");
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");
/* harmony import */ var _code__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./code */ "./resources/js/src/views/forms/form-element/form-textarea/code.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//



/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    BCardCode: _core_components_b_card_code__WEBPACK_IMPORTED_MODULE_0__["default"],
    BFormTextarea: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BFormTextarea"],
    BRow: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BRow"],
    BCardText: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BCardText"],
    BCol: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BCol"]
  },
  data: function data() {
    return {
      codeSize: _code__WEBPACK_IMPORTED_MODULE_2__["codeSize"]
    };
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaStates.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaStates.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _core_components_b_card_code__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @core/components/b-card-code */ "./resources/js/src/@core/components/b-card-code/index.js");
/* harmony import */ var bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js");
/* harmony import */ var _code__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./code */ "./resources/js/src/views/forms/form-element/form-textarea/code.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//



/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    BCardCode: _core_components_b_card_code__WEBPACK_IMPORTED_MODULE_0__["default"],
    BFormTextarea: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BFormTextarea"],
    BCardText: bootstrap_vue__WEBPACK_IMPORTED_MODULE_1__["BCardText"]
  },
  data: function data() {
    return {
      text: '',
      codeStates: _code__WEBPACK_IMPORTED_MODULE_2__["codeStates"]
    };
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/forms/form-element/form-textarea/FormTextArea.vue?vue&type=template&id=6f81f9ec&":
/*!***********************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/forms/form-element/form-textarea/FormTextArea.vue?vue&type=template&id=6f81f9ec& ***!
  \***********************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "b-row",
    [
      _c(
        "b-col",
        { attrs: { cols: "12" } },
        [
          _c("form-text-area-default"),
          _vm._v(" "),
          _c("form-text-area-rows"),
          _vm._v(" "),
          _c("form-text-area-floating-label"),
          _vm._v(" "),
          _c("form-text-area-states"),
          _vm._v(" "),
          _c("form-text-area-size"),
          _vm._v(" "),
          _c("form-text-area-disable-resize"),
          _vm._v(" "),
          _c("form-text-area-auto-height"),
          _vm._v(" "),
          _c("formatter-text-area"),
          _vm._v(" "),
          _c("form-text-area-readonly"),
          _vm._v(" "),
          _c("form-text-area-debounce"),
          _vm._v(" "),
          _c("form-text-area-counter"),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaAutoHeight.vue?vue&type=template&id=368c047c&":
/*!*********************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaAutoHeight.vue?vue&type=template&id=368c047c& ***!
  \*********************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "b-card-code",
    {
      attrs: { title: "Auto height" },
      scopedSlots: _vm._u([
        {
          key: "code",
          fn: function () {
            return [_vm._v("\n    " + _vm._s(_vm.codeAutoHeight) + "\n  ")]
          },
          proxy: true,
        },
      ]),
    },
    [
      _c("b-card-text", [
        _c("span", [
          _vm._v("To set the initial minimum height (in rows), set the"),
        ]),
        _vm._v(" "),
        _c("code", [_vm._v("rows")]),
        _vm._v(" "),
        _c("span", [
          _vm._v(
            " prop to the desired number of lines (or leave it at the default of "
          ),
        ]),
        _vm._v(" "),
        _c("code", [_vm._v("2")]),
        _vm._v(" "),
        _c("span", [
          _vm._v(
            "), And then set maximum rows that the text area will grow to (before showing a scrollbar) by setting the\n    "
          ),
        ]),
        _vm._v(" "),
        _c("code", [_vm._v("max-rows")]),
        _vm._v(" "),
        _c("span", [_vm._v("prop to the maximum number of lines of text.")]),
      ]),
      _vm._v(" "),
      _c("b-card-text", [
        _c("span", [_vm._v("To make the height ")]),
        _vm._v(" "),
        _c("code", [_vm._v("sticky")]),
        _vm._v(" "),
        _c("span", [_vm._v(" (i.e. never shrink), set the ")]),
        _vm._v(" "),
        _c("code", [_vm._v("no-auto-shrink")]),
        _vm._v(" "),
        _c("span", [_vm._v(" prop to ")]),
        _vm._v(" "),
        _c("code", [_vm._v("true")]),
        _vm._v(" "),
        _c("span", [_vm._v(". The ")]),
        _vm._v(" "),
        _c("code", [_vm._v("no-auto-shrink")]),
        _vm._v(" "),
        _c("span", [_vm._v(" props has no effect if ")]),
        _vm._v(" "),
        _c("code", [_vm._v("max-rows")]),
        _vm._v(" "),
        _c("span", [_vm._v(" is not set or is equal to or less than rows.")]),
      ]),
      _vm._v(" "),
      _c(
        "b-row",
        [
          _c(
            "b-col",
            { attrs: { xl: "6", cols: "12" } },
            [
              _c("label", { attrs: { for: "textarea-auto-height" } }, [
                _vm._v("Auto height:"),
              ]),
              _vm._v(" "),
              _c("b-form-textarea", {
                staticClass: "mb-1 mb-xl-0",
                attrs: {
                  id: "textarea-auto-height",
                  placeholder: "Auto height textarea",
                  rows: "3",
                  "max-rows": "8",
                },
              }),
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "b-col",
            { attrs: { xl: "6", cols: "12" } },
            [
              _c("label", { attrs: { for: "textarea-no-auto-shrink" } }, [
                _vm._v("No auto-shrink:"),
              ]),
              _vm._v(" "),
              _c("b-form-textarea", {
                attrs: {
                  id: "textarea-no-auto-shrink",
                  placeholder: "Auto height (no-shrink) textarea",
                  rows: "3",
                  "max-rows": "8",
                  "no-auto-shrink": "",
                },
              }),
            ],
            1
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaCounter.vue?vue&type=template&id=1f6436c0&":
/*!******************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaCounter.vue?vue&type=template&id=1f6436c0& ***!
  \******************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "b-card-code",
    {
      attrs: { title: "Counter" },
      scopedSlots: _vm._u([
        {
          key: "code",
          fn: function () {
            return [_vm._v("\n    " + _vm._s(_vm.codeCounter) + "\n  ")]
          },
          proxy: true,
        },
      ]),
    },
    [
      _c("b-card-text", [
        _vm._v(
          "\n    There are times when we need the user to only enter a certain number of characters for it, we have the property\n    counter, the value is a number and determines the maximum.\n  "
        ),
      ]),
      _vm._v(" "),
      _c("b-form-textarea", {
        staticClass: "char-textarea",
        class: _vm.value.length >= _vm.maxChar ? "text-danger" : "",
        attrs: {
          placeholder: "Counter",
          rows: "3",
          state: _vm.value.length <= _vm.maxChar,
        },
        model: {
          value: _vm.value,
          callback: function ($$v) {
            _vm.value = $$v
          },
          expression: "value",
        },
      }),
      _vm._v(" "),
      _c(
        "small",
        {
          staticClass: "textarea-counter-value float-right",
          class: _vm.value.length >= _vm.maxChar ? "bg-danger" : "",
        },
        [
          _c("span", { staticClass: "char-count" }, [
            _vm._v(_vm._s(_vm.value.length)),
          ]),
          _vm._v(" / " + _vm._s(_vm.maxChar) + "\n  "),
        ]
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaDebounce.vue?vue&type=template&id=1f6d6856&":
/*!*******************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaDebounce.vue?vue&type=template&id=1f6d6856& ***!
  \*******************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "b-card-code",
    {
      attrs: { title: "Debounce support" },
      scopedSlots: _vm._u([
        {
          key: "code",
          fn: function () {
            return [_vm._v("\n    " + _vm._s(_vm.codeDebounce) + "\n  ")]
          },
          proxy: true,
        },
      ]),
    },
    [
      _c("b-card-text", [
        _c("span", [_vm._v("To enable debouncing, set the prop ")]),
        _vm._v(" "),
        _c("code", [_vm._v("debounce")]),
        _vm._v(" "),
        _c("span", [
          _vm._v(
            " to any integer greater than zero. The value is specified in milliseconds. Setting "
          ),
        ]),
        _vm._v(" "),
        _c("code", [_vm._v("debounce")]),
        _vm._v(" "),
        _c("span", [_vm._v(" to ")]),
        _vm._v(" "),
        _c("code", [_vm._v("0")]),
        _vm._v(" "),
        _c("span", [_vm._v(" will disable debouncing.")]),
      ]),
      _vm._v(" "),
      _c("b-form-textarea", {
        attrs: { debounce: "500", rows: "3", "max-rows": "5" },
        model: {
          value: _vm.value,
          callback: function ($$v) {
            _vm.value = $$v
          },
          expression: "value",
        },
      }),
      _vm._v(" "),
      _c("b-card-text", { staticClass: "mt-1 mb-0" }, [
        _vm._v("\n    " + _vm._s(_vm.value) + "\n  "),
      ]),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaDefault.vue?vue&type=template&id=44d6ba65&":
/*!******************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaDefault.vue?vue&type=template&id=44d6ba65& ***!
  \******************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "b-card-code",
    {
      attrs: { title: "Default" },
      scopedSlots: _vm._u([
        {
          key: "code",
          fn: function () {
            return [_vm._v("\n    " + _vm._s(_vm.codeDefault) + "\n  ")]
          },
          proxy: true,
        },
      ]),
    },
    [
      _c("b-card-text", [
        _vm._v(
          "\n    Create multi-line text inputs with support for auto height sizing, minimum and maximum number of rows, and\n    contextual states.\n  "
        ),
      ]),
      _vm._v(" "),
      _c("label", { attrs: { for: "textarea-default" } }, [_vm._v("Textarea")]),
      _vm._v(" "),
      _c("b-form-textarea", {
        attrs: { id: "textarea-default", placeholder: "Textarea", rows: "3" },
      }),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaDisableResize.vue?vue&type=template&id=120e5940&":
/*!************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaDisableResize.vue?vue&type=template&id=120e5940& ***!
  \************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "b-card-code",
    {
      attrs: { title: "Disable resize handle" },
      scopedSlots: _vm._u([
        {
          key: "code",
          fn: function () {
            return [_vm._v("\n    " + _vm._s(_vm.codeDisableResize) + "\n  ")]
          },
          proxy: true,
        },
      ]),
    },
    [
      _c("b-card-text", [
        _c("span", [
          _vm._v(
            "\n      Some web browsers will allow the user to re-size the height of the textarea. To disable this feature, set the\n    "
          ),
        ]),
        _vm._v(" "),
        _c("code", [_vm._v("no-resize")]),
        _vm._v(" "),
        _c("span", [_vm._v(" prop to ")]),
        _vm._v(" "),
        _c("code", [_vm._v("true")]),
        _vm._v(" "),
        _c("span", [_vm._v(".")]),
      ]),
      _vm._v(" "),
      _c("b-form-textarea", {
        attrs: {
          id: "textarea-no-resize",
          placeholder: "Fixed height textarea",
          rows: "3",
          "no-resize": "",
        },
      }),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaFloatingLabel.vue?vue&type=template&id=6b83d732&":
/*!************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaFloatingLabel.vue?vue&type=template&id=6b83d732& ***!
  \************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "b-card-code",
    {
      attrs: { title: "Floating Label" },
      scopedSlots: _vm._u([
        {
          key: "code",
          fn: function () {
            return [_vm._v("\n    " + _vm._s(_vm.codeFloatingLabel) + "\n  ")]
          },
          proxy: true,
        },
      ]),
    },
    [
      _c("b-card-text", [
        _c("span", [_vm._v("Use ")]),
        _vm._v(" "),
        _c("code", [_vm._v(".form-label-group")]),
        _vm._v(" "),
        _c("span", [_vm._v(" to add a Floating Label with Textarea.")]),
      ]),
      _vm._v(" "),
      _c(
        "div",
        { staticClass: "form-label-group mt-2 mb-0" },
        [
          _c("b-form-textarea", {
            attrs: {
              id: "textarea",
              rows: "3",
              placeholder: "Label in Textarea",
            },
          }),
          _vm._v(" "),
          _c("label", { attrs: { for: "label-textarea" } }, [
            _vm._v("Label in Textarea"),
          ]),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaFormatter.vue?vue&type=template&id=0964d56e&":
/*!********************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaFormatter.vue?vue&type=template&id=0964d56e& ***!
  \********************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "b-card-code",
    {
      attrs: { title: "Formatter support" },
      scopedSlots: _vm._u([
        {
          key: "code",
          fn: function () {
            return [_vm._v("\n    " + _vm._s(_vm.codeFormatter) + "\n  ")]
          },
          proxy: true,
        },
      ]),
    },
    [
      _c("b-card-text", [
        _c("code", [_vm._v("<b-form-textarea>")]),
        _vm._v(" "),
        _c("span", [
          _vm._v(
            "optionally supports formatting by passing a function reference to the "
          ),
        ]),
        _vm._v(" "),
        _c("code", [_vm._v("formatter")]),
        _vm._v(" "),
        _c("span", [_vm._v(" prop.")]),
      ]),
      _vm._v(" "),
      _c(
        "div",
        [
          _c(
            "b-form-group",
            {
              attrs: {
                label: "Textarea with formatter (on input)",
                "label-for": "textarea-formatter",
                description: "We will convert your text to lowercase instantly",
              },
            },
            [
              _c("b-form-textarea", {
                attrs: {
                  id: "textarea-formatter",
                  placeholder: "Enter your text",
                  formatter: _vm.formatter,
                },
                model: {
                  value: _vm.text1,
                  callback: function ($$v) {
                    _vm.text1 = $$v
                  },
                  expression: "text1",
                },
              }),
            ],
            1
          ),
          _vm._v(" "),
          _c("b-card-text", [
            _c("strong", [_vm._v("Value:")]),
            _vm._v(" " + _vm._s(_vm.text1)),
          ]),
          _vm._v(" "),
          _c(
            "b-form-group",
            {
              attrs: {
                label: "Textarea with lazy formatter (on blur)",
                "label-for": "textarea-lazy",
                description: "This one is a little lazy!",
              },
            },
            [
              _c("b-form-textarea", {
                attrs: {
                  id: "textarea-lazy",
                  placeholder: "Enter your text",
                  "lazy-formatter": "",
                  formatter: _vm.formatter,
                },
                model: {
                  value: _vm.text2,
                  callback: function ($$v) {
                    _vm.text2 = $$v
                  },
                  expression: "text2",
                },
              }),
            ],
            1
          ),
          _vm._v(" "),
          _c("b-card-text", [
            _c("strong", [_vm._v("Value:")]),
            _vm._v(" " + _vm._s(_vm.text2)),
          ]),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaReadonly.vue?vue&type=template&id=ac16f164&":
/*!*******************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaReadonly.vue?vue&type=template&id=ac16f164& ***!
  \*******************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "b-card-code",
    {
      attrs: { title: "Readonly plain text" },
      scopedSlots: _vm._u([
        {
          key: "code",
          fn: function () {
            return [_vm._v("\n    " + _vm._s(_vm.codeReadonly) + "\n  ")]
          },
          proxy: true,
        },
      ]),
    },
    [
      _c("b-card-text", [
        _c("span", [_vm._v("If you want to have ")]),
        _vm._v(" "),
        _c("code", [_vm._v("<b-form-textarea readonly>")]),
        _vm._v(" "),
        _c("span", [
          _vm._v(" elements in your form styled as plain text, set the "),
        ]),
        _vm._v(" "),
        _c("code", [_vm._v("plaintext")]),
        _vm._v(" "),
        _c("span", [_vm._v(" prop (no need to set ")]),
        _vm._v(" "),
        _c("code", [_vm._v("readonly")]),
        _vm._v(" "),
        _c("span", [
          _vm._v(
            "\n      as it will be set automatically) to remove the default form field styling and preserve the correct text size,\n      margin, padding and height.\n    "
          ),
        ]),
      ]),
      _vm._v(" "),
      _c("b-form-textarea", {
        attrs: { id: "textarea-plaintext", readonly: "", value: _vm.text },
      }),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaRows.vue?vue&type=template&id=9300fd36&":
/*!***************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaRows.vue?vue&type=template&id=9300fd36& ***!
  \***************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "b-card-code",
    {
      attrs: { title: "Displayed rows" },
      scopedSlots: _vm._u([
        {
          key: "code",
          fn: function () {
            return [_vm._v("\n    " + _vm._s(_vm.codeRows) + "\n  ")]
          },
          proxy: true,
        },
      ]),
    },
    [
      _c("b-card-text", [
        _c("span", [_vm._v("To set the height of ")]),
        _vm._v(" "),
        _c("code", [_vm._v("<b-form-textarea>")]),
        _vm._v(" "),
        _c("span", [_vm._v(", set the ")]),
        _vm._v(" "),
        _c("code", [_vm._v("rows")]),
        _vm._v(" "),
        _c("span", [
          _vm._v(
            " prop to the desired number of rows. If no value is provided to rows, then it will default to 2."
          ),
        ]),
      ]),
      _vm._v(" "),
      _c("b-form-textarea", {
        attrs: { id: "textarea-rows", placeholder: "Tall textarea", rows: "8" },
      }),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaSize.vue?vue&type=template&id=3556e8e6&":
/*!***************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaSize.vue?vue&type=template&id=3556e8e6& ***!
  \***************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "b-card-code",
    {
      attrs: { title: "Control sizing" },
      scopedSlots: _vm._u([
        {
          key: "code",
          fn: function () {
            return [_vm._v("\n    " + _vm._s(_vm.codeSize) + "\n  ")]
          },
          proxy: true,
        },
      ]),
    },
    [
      _c("b-card-text", [
        _c("span", [_vm._v("Set text height using the ")]),
        _vm._v(" "),
        _c("code", [_vm._v("size")]),
        _vm._v(" "),
        _c("span", [_vm._v(" prop to ")]),
        _vm._v(" "),
        _c("code", [_vm._v("sm")]),
        _vm._v(" "),
        _c("span", [_vm._v(" or ")]),
        _vm._v(" "),
        _c("code", [_vm._v("lg")]),
        _vm._v(" "),
        _c("span", [_vm._v(" for small or large respectively.")]),
      ]),
      _vm._v(" "),
      _c(
        "b-row",
        [
          _c("b-col", { attrs: { sm: "2" } }, [
            _c(
              "label",
              { staticClass: "text-nowrap", attrs: { for: "textarea-small" } },
              [_vm._v("Small:")]
            ),
          ]),
          _vm._v(" "),
          _c(
            "b-col",
            { staticClass: "mb-1", attrs: { sm: "10" } },
            [
              _c("b-form-textarea", {
                attrs: {
                  id: "textarea-small",
                  size: "sm",
                  placeholder: "Small textarea",
                },
              }),
            ],
            1
          ),
          _vm._v(" "),
          _c("b-col", { attrs: { sm: "2" } }, [
            _c(
              "label",
              {
                staticClass: "text-nowrap",
                attrs: { for: "textarea-default" },
              },
              [_vm._v("Default:")]
            ),
          ]),
          _vm._v(" "),
          _c(
            "b-col",
            { staticClass: "mb-1", attrs: { sm: "10" } },
            [
              _c("b-form-textarea", {
                attrs: {
                  id: "textarea-default",
                  placeholder: "Default textarea",
                },
              }),
            ],
            1
          ),
          _vm._v(" "),
          _c("b-col", { attrs: { sm: "2" } }, [
            _c(
              "label",
              { staticClass: "text-nowrap", attrs: { for: "textarea-large" } },
              [_vm._v("Large:")]
            ),
          ]),
          _vm._v(" "),
          _c(
            "b-col",
            { staticClass: "mb-1", attrs: { sm: "10" } },
            [
              _c("b-form-textarea", {
                attrs: {
                  id: "textarea-large",
                  size: "lg",
                  placeholder: "Large textarea",
                },
              }),
            ],
            1
          ),
        ],
        1
      ),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaStates.vue?vue&type=template&id=d93df7e4&":
/*!*****************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaStates.vue?vue&type=template&id=d93df7e4& ***!
  \*****************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "b-card-code",
    {
      attrs: { title: "Contextual states" },
      scopedSlots: _vm._u([
        {
          key: "code",
          fn: function () {
            return [_vm._v("\n    " + _vm._s(_vm.codeStates) + "\n  ")]
          },
          proxy: true,
        },
      ]),
    },
    [
      _c("b-card-text", [
        _c("span", [_vm._v("Bootstrap includes validation styles for ")]),
        _vm._v(" "),
        _c("code", [_vm._v("valid")]),
        _vm._v(" "),
        _c("span", [_vm._v(" and ")]),
        _vm._v(" "),
        _c("code", [_vm._v("invalid")]),
        _vm._v(" "),
        _c("span", [_vm._v(" states on most form controls.")]),
      ]),
      _vm._v(" "),
      _c("b-form-textarea", {
        attrs: {
          id: "textarea-state",
          state: _vm.text.length <= 10,
          placeholder: "Enter only 10 characters",
          rows: "3",
        },
        model: {
          value: _vm.text,
          callback: function ($$v) {
            _vm.text = $$v
          },
          expression: "text",
        },
      }),
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./resources/js/src/@core/components/b-card-code/index.js":
/*!****************************************************************!*\
  !*** ./resources/js/src/@core/components/b-card-code/index.js ***!
  \****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _BCardCode_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./BCardCode.vue */ "./resources/js/src/@core/components/b-card-code/BCardCode.vue");

/* harmony default export */ __webpack_exports__["default"] = (_BCardCode_vue__WEBPACK_IMPORTED_MODULE_0__["default"]);

/***/ }),

/***/ "./resources/js/src/views/forms/form-element/form-textarea/FormTextArea.vue":
/*!**********************************************************************************!*\
  !*** ./resources/js/src/views/forms/form-element/form-textarea/FormTextArea.vue ***!
  \**********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _FormTextArea_vue_vue_type_template_id_6f81f9ec___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./FormTextArea.vue?vue&type=template&id=6f81f9ec& */ "./resources/js/src/views/forms/form-element/form-textarea/FormTextArea.vue?vue&type=template&id=6f81f9ec&");
/* harmony import */ var _FormTextArea_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./FormTextArea.vue?vue&type=script&lang=js& */ "./resources/js/src/views/forms/form-element/form-textarea/FormTextArea.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _FormTextArea_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _FormTextArea_vue_vue_type_template_id_6f81f9ec___WEBPACK_IMPORTED_MODULE_0__["render"],
  _FormTextArea_vue_vue_type_template_id_6f81f9ec___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/forms/form-element/form-textarea/FormTextArea.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/forms/form-element/form-textarea/FormTextArea.vue?vue&type=script&lang=js&":
/*!***********************************************************************************************************!*\
  !*** ./resources/js/src/views/forms/form-element/form-textarea/FormTextArea.vue?vue&type=script&lang=js& ***!
  \***********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FormTextArea_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./FormTextArea.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/forms/form-element/form-textarea/FormTextArea.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FormTextArea_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/forms/form-element/form-textarea/FormTextArea.vue?vue&type=template&id=6f81f9ec&":
/*!*****************************************************************************************************************!*\
  !*** ./resources/js/src/views/forms/form-element/form-textarea/FormTextArea.vue?vue&type=template&id=6f81f9ec& ***!
  \*****************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_FormTextArea_vue_vue_type_template_id_6f81f9ec___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./FormTextArea.vue?vue&type=template&id=6f81f9ec& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/forms/form-element/form-textarea/FormTextArea.vue?vue&type=template&id=6f81f9ec&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_FormTextArea_vue_vue_type_template_id_6f81f9ec___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_FormTextArea_vue_vue_type_template_id_6f81f9ec___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaAutoHeight.vue":
/*!********************************************************************************************!*\
  !*** ./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaAutoHeight.vue ***!
  \********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _FormTextAreaAutoHeight_vue_vue_type_template_id_368c047c___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./FormTextAreaAutoHeight.vue?vue&type=template&id=368c047c& */ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaAutoHeight.vue?vue&type=template&id=368c047c&");
/* harmony import */ var _FormTextAreaAutoHeight_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./FormTextAreaAutoHeight.vue?vue&type=script&lang=js& */ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaAutoHeight.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _FormTextAreaAutoHeight_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _FormTextAreaAutoHeight_vue_vue_type_template_id_368c047c___WEBPACK_IMPORTED_MODULE_0__["render"],
  _FormTextAreaAutoHeight_vue_vue_type_template_id_368c047c___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/forms/form-element/form-textarea/FormTextAreaAutoHeight.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaAutoHeight.vue?vue&type=script&lang=js&":
/*!*********************************************************************************************************************!*\
  !*** ./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaAutoHeight.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FormTextAreaAutoHeight_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./FormTextAreaAutoHeight.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaAutoHeight.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FormTextAreaAutoHeight_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaAutoHeight.vue?vue&type=template&id=368c047c&":
/*!***************************************************************************************************************************!*\
  !*** ./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaAutoHeight.vue?vue&type=template&id=368c047c& ***!
  \***************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_FormTextAreaAutoHeight_vue_vue_type_template_id_368c047c___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./FormTextAreaAutoHeight.vue?vue&type=template&id=368c047c& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaAutoHeight.vue?vue&type=template&id=368c047c&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_FormTextAreaAutoHeight_vue_vue_type_template_id_368c047c___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_FormTextAreaAutoHeight_vue_vue_type_template_id_368c047c___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaCounter.vue":
/*!*****************************************************************************************!*\
  !*** ./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaCounter.vue ***!
  \*****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _FormTextAreaCounter_vue_vue_type_template_id_1f6436c0___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./FormTextAreaCounter.vue?vue&type=template&id=1f6436c0& */ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaCounter.vue?vue&type=template&id=1f6436c0&");
/* harmony import */ var _FormTextAreaCounter_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./FormTextAreaCounter.vue?vue&type=script&lang=js& */ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaCounter.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _FormTextAreaCounter_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _FormTextAreaCounter_vue_vue_type_template_id_1f6436c0___WEBPACK_IMPORTED_MODULE_0__["render"],
  _FormTextAreaCounter_vue_vue_type_template_id_1f6436c0___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/forms/form-element/form-textarea/FormTextAreaCounter.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaCounter.vue?vue&type=script&lang=js&":
/*!******************************************************************************************************************!*\
  !*** ./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaCounter.vue?vue&type=script&lang=js& ***!
  \******************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FormTextAreaCounter_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./FormTextAreaCounter.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaCounter.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FormTextAreaCounter_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaCounter.vue?vue&type=template&id=1f6436c0&":
/*!************************************************************************************************************************!*\
  !*** ./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaCounter.vue?vue&type=template&id=1f6436c0& ***!
  \************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_FormTextAreaCounter_vue_vue_type_template_id_1f6436c0___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./FormTextAreaCounter.vue?vue&type=template&id=1f6436c0& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaCounter.vue?vue&type=template&id=1f6436c0&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_FormTextAreaCounter_vue_vue_type_template_id_1f6436c0___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_FormTextAreaCounter_vue_vue_type_template_id_1f6436c0___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaDebounce.vue":
/*!******************************************************************************************!*\
  !*** ./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaDebounce.vue ***!
  \******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _FormTextAreaDebounce_vue_vue_type_template_id_1f6d6856___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./FormTextAreaDebounce.vue?vue&type=template&id=1f6d6856& */ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaDebounce.vue?vue&type=template&id=1f6d6856&");
/* harmony import */ var _FormTextAreaDebounce_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./FormTextAreaDebounce.vue?vue&type=script&lang=js& */ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaDebounce.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _FormTextAreaDebounce_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _FormTextAreaDebounce_vue_vue_type_template_id_1f6d6856___WEBPACK_IMPORTED_MODULE_0__["render"],
  _FormTextAreaDebounce_vue_vue_type_template_id_1f6d6856___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/forms/form-element/form-textarea/FormTextAreaDebounce.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaDebounce.vue?vue&type=script&lang=js&":
/*!*******************************************************************************************************************!*\
  !*** ./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaDebounce.vue?vue&type=script&lang=js& ***!
  \*******************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FormTextAreaDebounce_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./FormTextAreaDebounce.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaDebounce.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FormTextAreaDebounce_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaDebounce.vue?vue&type=template&id=1f6d6856&":
/*!*************************************************************************************************************************!*\
  !*** ./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaDebounce.vue?vue&type=template&id=1f6d6856& ***!
  \*************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_FormTextAreaDebounce_vue_vue_type_template_id_1f6d6856___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./FormTextAreaDebounce.vue?vue&type=template&id=1f6d6856& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaDebounce.vue?vue&type=template&id=1f6d6856&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_FormTextAreaDebounce_vue_vue_type_template_id_1f6d6856___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_FormTextAreaDebounce_vue_vue_type_template_id_1f6d6856___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaDefault.vue":
/*!*****************************************************************************************!*\
  !*** ./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaDefault.vue ***!
  \*****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _FormTextAreaDefault_vue_vue_type_template_id_44d6ba65___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./FormTextAreaDefault.vue?vue&type=template&id=44d6ba65& */ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaDefault.vue?vue&type=template&id=44d6ba65&");
/* harmony import */ var _FormTextAreaDefault_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./FormTextAreaDefault.vue?vue&type=script&lang=js& */ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaDefault.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _FormTextAreaDefault_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _FormTextAreaDefault_vue_vue_type_template_id_44d6ba65___WEBPACK_IMPORTED_MODULE_0__["render"],
  _FormTextAreaDefault_vue_vue_type_template_id_44d6ba65___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/forms/form-element/form-textarea/FormTextAreaDefault.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaDefault.vue?vue&type=script&lang=js&":
/*!******************************************************************************************************************!*\
  !*** ./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaDefault.vue?vue&type=script&lang=js& ***!
  \******************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FormTextAreaDefault_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./FormTextAreaDefault.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaDefault.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FormTextAreaDefault_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaDefault.vue?vue&type=template&id=44d6ba65&":
/*!************************************************************************************************************************!*\
  !*** ./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaDefault.vue?vue&type=template&id=44d6ba65& ***!
  \************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_FormTextAreaDefault_vue_vue_type_template_id_44d6ba65___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./FormTextAreaDefault.vue?vue&type=template&id=44d6ba65& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaDefault.vue?vue&type=template&id=44d6ba65&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_FormTextAreaDefault_vue_vue_type_template_id_44d6ba65___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_FormTextAreaDefault_vue_vue_type_template_id_44d6ba65___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaDisableResize.vue":
/*!***********************************************************************************************!*\
  !*** ./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaDisableResize.vue ***!
  \***********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _FormTextAreaDisableResize_vue_vue_type_template_id_120e5940___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./FormTextAreaDisableResize.vue?vue&type=template&id=120e5940& */ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaDisableResize.vue?vue&type=template&id=120e5940&");
/* harmony import */ var _FormTextAreaDisableResize_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./FormTextAreaDisableResize.vue?vue&type=script&lang=js& */ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaDisableResize.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _FormTextAreaDisableResize_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _FormTextAreaDisableResize_vue_vue_type_template_id_120e5940___WEBPACK_IMPORTED_MODULE_0__["render"],
  _FormTextAreaDisableResize_vue_vue_type_template_id_120e5940___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/forms/form-element/form-textarea/FormTextAreaDisableResize.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaDisableResize.vue?vue&type=script&lang=js&":
/*!************************************************************************************************************************!*\
  !*** ./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaDisableResize.vue?vue&type=script&lang=js& ***!
  \************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FormTextAreaDisableResize_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./FormTextAreaDisableResize.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaDisableResize.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FormTextAreaDisableResize_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaDisableResize.vue?vue&type=template&id=120e5940&":
/*!******************************************************************************************************************************!*\
  !*** ./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaDisableResize.vue?vue&type=template&id=120e5940& ***!
  \******************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_FormTextAreaDisableResize_vue_vue_type_template_id_120e5940___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./FormTextAreaDisableResize.vue?vue&type=template&id=120e5940& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaDisableResize.vue?vue&type=template&id=120e5940&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_FormTextAreaDisableResize_vue_vue_type_template_id_120e5940___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_FormTextAreaDisableResize_vue_vue_type_template_id_120e5940___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaFloatingLabel.vue":
/*!***********************************************************************************************!*\
  !*** ./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaFloatingLabel.vue ***!
  \***********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _FormTextAreaFloatingLabel_vue_vue_type_template_id_6b83d732___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./FormTextAreaFloatingLabel.vue?vue&type=template&id=6b83d732& */ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaFloatingLabel.vue?vue&type=template&id=6b83d732&");
/* harmony import */ var _FormTextAreaFloatingLabel_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./FormTextAreaFloatingLabel.vue?vue&type=script&lang=js& */ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaFloatingLabel.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _FormTextAreaFloatingLabel_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _FormTextAreaFloatingLabel_vue_vue_type_template_id_6b83d732___WEBPACK_IMPORTED_MODULE_0__["render"],
  _FormTextAreaFloatingLabel_vue_vue_type_template_id_6b83d732___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/forms/form-element/form-textarea/FormTextAreaFloatingLabel.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaFloatingLabel.vue?vue&type=script&lang=js&":
/*!************************************************************************************************************************!*\
  !*** ./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaFloatingLabel.vue?vue&type=script&lang=js& ***!
  \************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FormTextAreaFloatingLabel_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./FormTextAreaFloatingLabel.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaFloatingLabel.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FormTextAreaFloatingLabel_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaFloatingLabel.vue?vue&type=template&id=6b83d732&":
/*!******************************************************************************************************************************!*\
  !*** ./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaFloatingLabel.vue?vue&type=template&id=6b83d732& ***!
  \******************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_FormTextAreaFloatingLabel_vue_vue_type_template_id_6b83d732___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./FormTextAreaFloatingLabel.vue?vue&type=template&id=6b83d732& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaFloatingLabel.vue?vue&type=template&id=6b83d732&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_FormTextAreaFloatingLabel_vue_vue_type_template_id_6b83d732___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_FormTextAreaFloatingLabel_vue_vue_type_template_id_6b83d732___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaFormatter.vue":
/*!*******************************************************************************************!*\
  !*** ./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaFormatter.vue ***!
  \*******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _FormTextAreaFormatter_vue_vue_type_template_id_0964d56e___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./FormTextAreaFormatter.vue?vue&type=template&id=0964d56e& */ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaFormatter.vue?vue&type=template&id=0964d56e&");
/* harmony import */ var _FormTextAreaFormatter_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./FormTextAreaFormatter.vue?vue&type=script&lang=js& */ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaFormatter.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _FormTextAreaFormatter_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _FormTextAreaFormatter_vue_vue_type_template_id_0964d56e___WEBPACK_IMPORTED_MODULE_0__["render"],
  _FormTextAreaFormatter_vue_vue_type_template_id_0964d56e___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/forms/form-element/form-textarea/FormTextAreaFormatter.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaFormatter.vue?vue&type=script&lang=js&":
/*!********************************************************************************************************************!*\
  !*** ./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaFormatter.vue?vue&type=script&lang=js& ***!
  \********************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FormTextAreaFormatter_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./FormTextAreaFormatter.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaFormatter.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FormTextAreaFormatter_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaFormatter.vue?vue&type=template&id=0964d56e&":
/*!**************************************************************************************************************************!*\
  !*** ./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaFormatter.vue?vue&type=template&id=0964d56e& ***!
  \**************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_FormTextAreaFormatter_vue_vue_type_template_id_0964d56e___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./FormTextAreaFormatter.vue?vue&type=template&id=0964d56e& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaFormatter.vue?vue&type=template&id=0964d56e&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_FormTextAreaFormatter_vue_vue_type_template_id_0964d56e___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_FormTextAreaFormatter_vue_vue_type_template_id_0964d56e___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaReadonly.vue":
/*!******************************************************************************************!*\
  !*** ./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaReadonly.vue ***!
  \******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _FormTextAreaReadonly_vue_vue_type_template_id_ac16f164___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./FormTextAreaReadonly.vue?vue&type=template&id=ac16f164& */ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaReadonly.vue?vue&type=template&id=ac16f164&");
/* harmony import */ var _FormTextAreaReadonly_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./FormTextAreaReadonly.vue?vue&type=script&lang=js& */ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaReadonly.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _FormTextAreaReadonly_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _FormTextAreaReadonly_vue_vue_type_template_id_ac16f164___WEBPACK_IMPORTED_MODULE_0__["render"],
  _FormTextAreaReadonly_vue_vue_type_template_id_ac16f164___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/forms/form-element/form-textarea/FormTextAreaReadonly.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaReadonly.vue?vue&type=script&lang=js&":
/*!*******************************************************************************************************************!*\
  !*** ./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaReadonly.vue?vue&type=script&lang=js& ***!
  \*******************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FormTextAreaReadonly_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./FormTextAreaReadonly.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaReadonly.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FormTextAreaReadonly_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaReadonly.vue?vue&type=template&id=ac16f164&":
/*!*************************************************************************************************************************!*\
  !*** ./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaReadonly.vue?vue&type=template&id=ac16f164& ***!
  \*************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_FormTextAreaReadonly_vue_vue_type_template_id_ac16f164___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./FormTextAreaReadonly.vue?vue&type=template&id=ac16f164& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaReadonly.vue?vue&type=template&id=ac16f164&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_FormTextAreaReadonly_vue_vue_type_template_id_ac16f164___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_FormTextAreaReadonly_vue_vue_type_template_id_ac16f164___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaRows.vue":
/*!**************************************************************************************!*\
  !*** ./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaRows.vue ***!
  \**************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _FormTextAreaRows_vue_vue_type_template_id_9300fd36___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./FormTextAreaRows.vue?vue&type=template&id=9300fd36& */ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaRows.vue?vue&type=template&id=9300fd36&");
/* harmony import */ var _FormTextAreaRows_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./FormTextAreaRows.vue?vue&type=script&lang=js& */ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaRows.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _FormTextAreaRows_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _FormTextAreaRows_vue_vue_type_template_id_9300fd36___WEBPACK_IMPORTED_MODULE_0__["render"],
  _FormTextAreaRows_vue_vue_type_template_id_9300fd36___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/forms/form-element/form-textarea/FormTextAreaRows.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaRows.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************************!*\
  !*** ./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaRows.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FormTextAreaRows_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./FormTextAreaRows.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaRows.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FormTextAreaRows_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaRows.vue?vue&type=template&id=9300fd36&":
/*!*********************************************************************************************************************!*\
  !*** ./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaRows.vue?vue&type=template&id=9300fd36& ***!
  \*********************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_FormTextAreaRows_vue_vue_type_template_id_9300fd36___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./FormTextAreaRows.vue?vue&type=template&id=9300fd36& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaRows.vue?vue&type=template&id=9300fd36&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_FormTextAreaRows_vue_vue_type_template_id_9300fd36___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_FormTextAreaRows_vue_vue_type_template_id_9300fd36___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaSize.vue":
/*!**************************************************************************************!*\
  !*** ./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaSize.vue ***!
  \**************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _FormTextAreaSize_vue_vue_type_template_id_3556e8e6___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./FormTextAreaSize.vue?vue&type=template&id=3556e8e6& */ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaSize.vue?vue&type=template&id=3556e8e6&");
/* harmony import */ var _FormTextAreaSize_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./FormTextAreaSize.vue?vue&type=script&lang=js& */ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaSize.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _FormTextAreaSize_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _FormTextAreaSize_vue_vue_type_template_id_3556e8e6___WEBPACK_IMPORTED_MODULE_0__["render"],
  _FormTextAreaSize_vue_vue_type_template_id_3556e8e6___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/forms/form-element/form-textarea/FormTextAreaSize.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaSize.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************************!*\
  !*** ./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaSize.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FormTextAreaSize_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./FormTextAreaSize.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaSize.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FormTextAreaSize_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaSize.vue?vue&type=template&id=3556e8e6&":
/*!*********************************************************************************************************************!*\
  !*** ./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaSize.vue?vue&type=template&id=3556e8e6& ***!
  \*********************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_FormTextAreaSize_vue_vue_type_template_id_3556e8e6___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./FormTextAreaSize.vue?vue&type=template&id=3556e8e6& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaSize.vue?vue&type=template&id=3556e8e6&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_FormTextAreaSize_vue_vue_type_template_id_3556e8e6___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_FormTextAreaSize_vue_vue_type_template_id_3556e8e6___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaStates.vue":
/*!****************************************************************************************!*\
  !*** ./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaStates.vue ***!
  \****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _FormTextAreaStates_vue_vue_type_template_id_d93df7e4___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./FormTextAreaStates.vue?vue&type=template&id=d93df7e4& */ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaStates.vue?vue&type=template&id=d93df7e4&");
/* harmony import */ var _FormTextAreaStates_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./FormTextAreaStates.vue?vue&type=script&lang=js& */ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaStates.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _FormTextAreaStates_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _FormTextAreaStates_vue_vue_type_template_id_d93df7e4___WEBPACK_IMPORTED_MODULE_0__["render"],
  _FormTextAreaStates_vue_vue_type_template_id_d93df7e4___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/forms/form-element/form-textarea/FormTextAreaStates.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaStates.vue?vue&type=script&lang=js&":
/*!*****************************************************************************************************************!*\
  !*** ./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaStates.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FormTextAreaStates_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./FormTextAreaStates.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaStates.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FormTextAreaStates_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaStates.vue?vue&type=template&id=d93df7e4&":
/*!***********************************************************************************************************************!*\
  !*** ./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaStates.vue?vue&type=template&id=d93df7e4& ***!
  \***********************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_FormTextAreaStates_vue_vue_type_template_id_d93df7e4___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./FormTextAreaStates.vue?vue&type=template&id=d93df7e4& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/forms/form-element/form-textarea/FormTextAreaStates.vue?vue&type=template&id=d93df7e4&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_FormTextAreaStates_vue_vue_type_template_id_d93df7e4___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_FormTextAreaStates_vue_vue_type_template_id_d93df7e4___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/forms/form-element/form-textarea/code.js":
/*!*************************************************************************!*\
  !*** ./resources/js/src/views/forms/form-element/form-textarea/code.js ***!
  \*************************************************************************/
/*! exports provided: codeAutoHeight, codeDebounce, codeDefault, codeDisableResize, codeFloatingLabel, codeFormatter, codeRows, codeReadonly, codeSize, codeStates, codeCounter */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "codeAutoHeight", function() { return codeAutoHeight; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "codeDebounce", function() { return codeDebounce; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "codeDefault", function() { return codeDefault; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "codeDisableResize", function() { return codeDisableResize; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "codeFloatingLabel", function() { return codeFloatingLabel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "codeFormatter", function() { return codeFormatter; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "codeRows", function() { return codeRows; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "codeReadonly", function() { return codeReadonly; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "codeSize", function() { return codeSize; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "codeStates", function() { return codeStates; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "codeCounter", function() { return codeCounter; });
var codeAutoHeight = "\n<template>\n  <b-row>\n    <b-col\n      xl=\"6\"\n      cols=\"12\"\n    >\n      <label for=\"textarea-auto-height\">Auto height:</label>\n      <b-form-textarea\n        id=\"textarea-auto-height\"\n        placeholder=\"Auto height textarea\"\n        rows=\"3\"\n        max-rows=\"8\"\n      />\n    </b-col>\n    <b-col\n      xl=\"6\"\n      cols=\"12\"\n    >\n      <label for=\"textarea-no-auto-shrink\">No auto-shrink:</label>\n      <b-form-textarea\n        id=\"textarea-no-auto-shrink\"\n        placeholder=\"Auto height (no-shrink) textarea\"\n        rows=\"3\"\n        max-rows=\"8\"\n        no-auto-shrink\n      />\n    </b-col>\n  </b-row>\n</template>\n\n<script>\nimport { BFormTextarea, BRow, BCol } from 'bootstrap-vue'\n\nexport default {\n  components: {\n    BFormTextarea,\n    BRow,\n    BCol,\n  },\n}\n</script>\n";
var codeDebounce = "\n<template>\n  <div>\n    <b-form-textarea\n      v-model=\"value\"\n      debounce=\"500\"\n      rows=\"3\"\n      max-rows=\"5\"\n    />\n    <pre class=\"mt-1\">{{ value }}</pre>\n  </div>\n</template>\n\n<script>\nimport { BFormTextarea } from 'bootstrap-vue'\n\nexport default {\n  components: {\n    BFormTextarea,\n  },\n  data: () => ({\n    value: '',\n  }),\n}\n</script>\n";
var codeDefault = "\n<template>\n  <div>\n    <label for=\"textarea-default\">Textarea</label>\n    <b-form-textarea\n      id=\"textarea-default\"\n      placeholder=\"Textarea\"\n      rows=\"3\"\n    />\n  </div>\n</template>\n\n<script>\nimport { BFormTextarea, BCardText } from 'bootstrap-vue'\n\nexport default {\n  components: {\n    BCardText,\n    BFormTextarea,\n  },\n}\n</script>\n\n";
var codeDisableResize = "\n<template>\n  <div>\n    <b-form-textarea\n      id=\"textarea-no-resize\"\n      placeholder=\"Fixed height textarea\"\n      rows=\"3\"\n      no-resize\n    />\n  </div>\n</template>\n\n<script>\nimport { BFormTextarea } from 'bootstrap-vue'\n\nexport default {\n  components: {\n    BFormTextarea,\n  },\n}\n</script>\n";
var codeFloatingLabel = "\n<template>\n  <div class=\"form-label-group\">\n    <b-form-textarea\n      id=\"textarea\"\n      rows=\"3\"\n      placeholder=\"Label in Textarea\"\n    />\n    <label for=\"label-textarea\">Label in Textarea</label>\n  </div>\n</template>\n\n<script>\nimport { BFormTextarea } from 'bootstrap-vue'\n\nexport default {\n  components: {\n    BFormTextarea,\n  },\n}\n</script>\n";
var codeFormatter = "\n<template>\n  <div>\n    <b-form-group\n      class=\"mb-0\"\n      label=\"Textarea with formatter (on input)\"\n      label-for=\"textarea-formatter\"\n      description=\"We will convert your text to lowercase instantly\"\n    >\n      <b-form-textarea\n        id=\"textarea-formatter\"\n        v-model=\"text1\"\n        placeholder=\"Enter your text\"\n        :formatter=\"formatter\"\n      />\n    </b-form-group>\n    <p><b>Value:</b> {{ text1 }}</p>\n\n    <b-form-group\n      class=\"mb-0\"\n      label=\"Textarea with lazy formatter (on blur)\"\n      label-for=\"textarea-lazy\"\n      description=\"This one is a little lazy!\"\n    >\n      <b-form-textarea\n        id=\"textarea-lazy\"\n        v-model=\"text2\"\n        placeholder=\"Enter your text\"\n        lazy-formatter\n        :formatter=\"formatter\"\n      />\n    </b-form-group>\n    <p><b>Value:</b> {{ text2 }}</p>\n  </div>\n</template>\n\n<script>\nimport { BFormTextarea, BFormGroup } from 'bootstrap-vue'\n\nexport default {\n  components: {\n    BFormTextarea,\n    BFormGroup,\n  },\n  data: () => ({\n    text1: '',\n    text2: '',\n  }),\n  methods: {\n    formatter(value) {\n      return value.toLowerCase()\n    },\n  },\n}\n</script>\n";
var codeRows = "\n<template>\n  <b-form-textarea\n    id=\"textarea-rows\"\n    placeholder=\"Tall textarea\"\n    rows=\"8\"\n  />\n</template>\n\n<script>\nimport { BFormTextarea} from 'bootstrap-vue'\n\nexport default {\n  components: {\n    BFormTextarea,\n  },\n}\n</script>\n";
var codeReadonly = "\n<template>\n  <div>\n    <b-form-textarea\n      id=\"textarea-plaintext\"\n      plaintext\n      :value=\"text\"\n    />\n  </div>\n</template>\n\n<script>\nimport { BFormTextarea } from 'bootstrap-vue'\n\nexport default {\n  components: {\n    BFormTextarea,\n  },\n  data: () => ({\n    text: \"This is some text.\nIt is read only and doesn't look like an input.\",\n  }),\n}\n</script>\n";
var codeSize = "\n<template>\n  <b-row>\n    <b-col sm=\"2\">\n      <label\n        for=\"textarea-small\"\n        class=\"text-nowrap\"\n      >Small:</label>\n    </b-col>\n    <b-col\n      sm=\"10\"\n      class=\"mb-1\"\n    >\n      <b-form-textarea\n        id=\"textarea-small\"\n        size=\"sm\"\n        placeholder=\"Small textarea\"\n      />\n    </b-col>\n    <b-col sm=\"2\">\n      <label\n        for=\"textarea-default\"\n        class=\"text-nowrap\"\n      >Default:</label>\n    </b-col>\n    <b-col\n      sm=\"10\"\n      class=\"mb-1\"\n    >\n      <b-form-textarea\n        id=\"textarea-default\"\n        placeholder=\"Default textarea\"\n      />\n    </b-col>\n    <b-col sm=\"2\">\n      <label\n        for=\"textarea-large\"\n        class=\"text-nowrap\"\n      >Large:</label>\n    </b-col>\n    <b-col\n      sm=\"10\"\n      class=\"mb-1\"\n    >\n      <b-form-textarea\n        id=\"textarea-large\"\n        size=\"lg\"\n        placeholder=\"Large textarea\"\n      />\n    </b-col>\n  </b-row>\n</template>\n\n<script>\nimport { BFormTextarea, BRow, BCol } from 'bootstrap-vue'\n\nexport default {\n  components: {\n    BFormTextarea,\n    BRow,\n    BCol,\n  },\n}\n</script>\n";
var codeStates = "\n<template>\n  <b-form-textarea\n    id=\"textarea-state\"\n    v-model=\"text\"\n    :state=\"text.length <= 10\"\n    placeholder=\"Enter only 10 characters\"\n    rows=\"3\"\n  />\n</template>\n\n<script>\nimport { BFormTextarea } from 'bootstrap-vue'\n\nexport default {\n  components: {\n    BFormTextarea,\n  },\n  data() {\n    return {\n      text: '',\n    }\n  },\n}\n</script>\n";
var codeCounter = "\n<template>\n  <div>\n    <b-form-textarea\n      id=\"textarea-state\"\n      v-model=\"text\"\n      :state=\"text.length <= 10\"\n      placeholder=\"Enter only 10 characters\"\n      rows=\"3\"\n    />\n  </div>\n</template>\n\n<script>\nimport { BFormTextarea } from 'bootstrap-vue'\n\nexport default {\n  components: {\n    BFormTextarea,\n  },\n  data: () => ({\n    value: '',\n    maxChar: 20,\n  }),\n}\n</script>\n";

/***/ })

}]);